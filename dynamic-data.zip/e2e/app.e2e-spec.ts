import { DynamicDataPage } from './app.po';

describe('dynamic-data App', () => {
  let page: DynamicDataPage;

  beforeEach(() => {
    page = new DynamicDataPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
