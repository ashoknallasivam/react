import { MinimumNumberValidatorDirective } from './minimum-number.directive';

describe('MinimumNumberValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new MinimumNumberValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
