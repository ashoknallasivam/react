import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector:
    '[dynamicMin],[minNumber][formControlName],[minNumber][formControl],[minNumber][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => MinimumNumberValidatorDirective),
      multi: true,
    },
  ],
})
export class MinimumNumberValidatorDirective implements Validator {
  @Input()
  minNumber: string;

  validate(control: FormControl): { [key: string]: any } {
    if (!control.value || !this.minNumber) {
      return null; // don't validate empty values to allow optional controls
    }
    const value = parseFloat(control.value);
    const min = parseFloat(this.minNumber);

    // Controls with NaN values after parsing should be treated as not having a
    // minimum, per the HTML forms spec: https://www.w3.org/TR/html5/forms.html#attr-input-min
    return !isNaN(value) && !isNaN(min) && value < min
      ? { min: { min, actual: control.value } }
      : null;
  }
}
