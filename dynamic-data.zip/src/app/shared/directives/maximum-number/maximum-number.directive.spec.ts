import { MaximumNumberValidatorDirective } from './maximum-number.directive';

describe('MaximumNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new MaximumNumberValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
