import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector:
    '[dynamicMin],[maxNumber][formControlName],[maxNumber][formControl],[maxNumber][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => MaximumNumberValidatorDirective),
      multi: true,
    },
  ],
})
export class MaximumNumberValidatorDirective implements Validator {
  @Input()
  maxNumber: string;

  validate(control: FormControl): { [key: string]: any } {
    if (!control.value || !this.maxNumber) {
      return null; // don't validate empty values to allow optional controls
    }
    const value = parseFloat(control.value);
    const max = parseFloat(this.maxNumber);

    // Controls with NaN values after parsing should be treated as not having a
    // maximum, per the HTML forms spec: https://www.w3.org/TR/html5/forms.html#attr-input-max
    return !isNaN(value) && !isNaN(max) && value > max
      ? { max: { max, actual: control.value } }
      : null;
  }
}
