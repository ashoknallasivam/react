import { MaximumDateValidatorDirective } from './maximum-date.directive';

describe('MaximumDateValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new MaximumDateValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
