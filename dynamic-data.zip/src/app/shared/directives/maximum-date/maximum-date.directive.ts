import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector:
    '[dynamicMaxDate],[maxDate][formControlName],[maxDate][formControl],[maxDate][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => MaximumDateValidatorDirective),
      multi: true,
    },
  ],
})
export class MaximumDateValidatorDirective implements Validator {
  @Input()
  maxDate: string;

  validate(control: FormControl): { [key: string]: any } {
    if (!control.value || !this.maxDate) {
      return null; // don't validate empty values to allow optional controls
    }
    const value = new Date(control.value);
    const max = new Date(this.maxDate);

    // Controls with NaN values after parsing should be treated as not having a
    // maximum, per the HTML forms spec: https://www.w3.org/TR/html5/forms.html#attr-input-max
    // !isDate(value) && !isDate(max) &&
    return value > max ? { max: { max, actual: control.value } } : null;
  }
}
