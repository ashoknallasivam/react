import { MinimumDateValidatorDirective } from './minimum-date.directive';

describe('MinimumDateValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new MinimumDateValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
