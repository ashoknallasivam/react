import { Directive, forwardRef, Input } from '@angular/core';
import { FormControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector:
    '[dynamicMinDate],[minDate][formControlName],[minDate][formControl],[minDate][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => MinimumDateValidatorDirective),
      multi: true,
    },
  ],
})
export class MinimumDateValidatorDirective implements Validator {
  @Input()
  minDate: string;

  validate(control: FormControl): { [key: string]: any } {
    if (!control.value || !this.minDate) {
      return null; // don't validate empty values to allow optional controls
    }
    const value = new Date(control.value);
    const min = new Date(this.minDate);

    // Controls with NaN values after parsing should be treated as not having a
    // minimum, per the HTML forms spec: https://www.w3.org/TR/html5/forms.html#attr-input-min
    // !isDate(value) && !isDate(min) &&
    return value < min ? { min: { min, actual: control.value } } : null;
  }
}
