// hold the common components, directives, and pipes
// and share them with the modules that need them.
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

// modules that consolidate commonly used stuff
import { NgxMaskModule } from 'ngx-mask';
import { MaterialModule } from '../material/material.module';
import {
    MaximumDateValidatorDirective,
    MaximumNumberValidatorDirective,
    MinimumDateValidatorDirective,
    MinimumNumberValidatorDirective
} from './directives';

@NgModule({
    imports: [CommonModule, MaterialModule, NgxMaskModule.forRoot()],
    declarations: [
        MinimumNumberValidatorDirective,
        MinimumDateValidatorDirective,
        MaximumNumberValidatorDirective,
        MaximumDateValidatorDirective
    ],
    exports: [
        CommonModule,
        MaterialModule,
        NgxMaskModule,

        MinimumNumberValidatorDirective,
        MinimumDateValidatorDirective,
        MaximumNumberValidatorDirective,
        MaximumDateValidatorDirective
    ]
})
export class SharedModule {}
