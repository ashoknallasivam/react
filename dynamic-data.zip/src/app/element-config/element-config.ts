import { ElementType } from './element-type';

import { ActionToolbarConfig } from './config/action-toolbar';
import { AddressConfig } from './config/address';
import { ArrayConfig } from './config/array';
import { ButtonConfig } from './config/button';
import { CheckboxConfig } from './config/checkbox';
import { CheckboxGroupConfig } from './config/checkbox-group';
import { DateConfig } from './config/date';
import { EmailConfig } from './config/email';
import { FieldsetConfig } from './config/fieldset';
import { HeadingConfig } from './config/heading';
import { LayoutEditorConfig } from './config/layout-editor';
import { NumberConfig } from './config/number';
import { PanelConfig } from './config/panel';
import { PasswordConfig } from './config/password';
import { PhoneConfig } from './config/phone';
import { RadioConfig } from './config/radio';
import { SelectConfig } from './config/select';
import { SlideToggleConfig } from './config/slide-toggle';
import { SliderConfig } from './config/slider';
import { SsnConfig } from './config/ssn';
import { StatesConfig } from './config/states';
import { StaticConfig } from './config/static';
import { StaticPanelConfig } from './config/static-panel';
import { TextConfig } from './config/text';
import { TextMaskConfig } from './config/text-mask';
import { TextareaConfig } from './config/textarea';
import { TimeConfig } from './config/time';
import { TypeSelectConfig } from './config/type-select';
import { ZipConfig } from './config/zip';

export class ElementConfig {
  private static includeLayoutEditor(element, includeEditor) {
    if (includeEditor) {
      const layoutEditor = ElementConfig.get(ElementType.LayoutEditor).layout;
      element.layout
        .find(e => e.name === 'options')
        .options.fields.push(layoutEditor);
    }
    return element;
  }

  public static get(elementType: string, includeEditor: boolean = false): any {
    switch (elementType) {
      case ElementType.ActionToolbar:
        return new ActionToolbarConfig();
      case ElementType.Address:
        return new AddressConfig();
      case ElementType.Array:
        const array = new ArrayConfig();
        return ElementConfig.includeLayoutEditor(array, includeEditor);
      case ElementType.Button:
        return new ButtonConfig();
      case ElementType.Checkbox:
        return new CheckboxConfig();
      case ElementType.CheckboxGroup:
        return new CheckboxGroupConfig();
      case ElementType.Date:
        return new DateConfig();
      case ElementType.Email:
        return new EmailConfig();
      case ElementType.Fieldset:
        const fieldset = new FieldsetConfig();
        return ElementConfig.includeLayoutEditor(fieldset, includeEditor);
      case ElementType.Heading:
        return new HeadingConfig();
      case ElementType.LayoutEditor:
        return new LayoutEditorConfig();
      case ElementType.Number:
        return new NumberConfig();
      case ElementType.Panel:
        const panel = new PanelConfig();
        return ElementConfig.includeLayoutEditor(panel, includeEditor);
      case ElementType.Password:
        return new PasswordConfig();
      case ElementType.Phone:
        return new PhoneConfig();
      case ElementType.Radio:
        return new RadioConfig();
      case ElementType.Select:
        return new SelectConfig();
      case ElementType.Slider:
        return new SliderConfig();
      case ElementType.SlideToggle:
        return new SlideToggleConfig();
      case ElementType.Ssn:
        return new SsnConfig();
      case ElementType.States:
        return new StatesConfig();
      case ElementType.Static:
        return new StaticConfig();
      case ElementType.StaticPanel:
        const staticPanel = new StaticPanelConfig();
        return ElementConfig.includeLayoutEditor(staticPanel, includeEditor);
      case ElementType.Text:
        return new TextConfig();
      case ElementType.Textarea:
        return new TextareaConfig();
      case ElementType.TextMask:
        return new TextMaskConfig();
      case ElementType.Time:
        return new TimeConfig();
      case ElementType.Zip:
        return new ZipConfig();
      default:
        throw new Error(
          `Trying to use an unsupported element type (${elementType}).`
        );
    }
  }

  public static getTypeSelection(): any {
    return new TypeSelectConfig();
  }

  public static hasNestedProperties(entity: any) {
    return (
      entity.options &&
      entity.options.fields &&
      Array.isArray(entity.options.fields) &&
      entity.type !== ElementType.CheckboxGroup
    );
  }

  public static parseEntity(entity: any, push: boolean = true): any {
    const configs = [];
    for(const e of entity) {
        const elementConfig: any = this.get(e.type);
      if (this.hasNestedProperties(e)) {
        elementConfig.layout
          .find(p => p.name === 'options')
          .options.fields.push(
            this.parseEntity(e.options.fields, false)
          );
      }
      configs.push(elementConfig.layout);
    }
   
    const config = this.get(ElementType.LayoutEditor).layout;
    config.options.fields = configs;

    if (!push) {
      return config;
    }

    const layout = [];
    layout.push(config);
    return layout;
  }
}
