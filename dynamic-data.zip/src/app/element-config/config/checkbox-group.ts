export class CheckboxGroupConfig {
    layout: any = [
        {
            type: 'heading',
            label: 'Checkbox group configuration',
            options: {
                level: 1
            }
        },
        {
            name: 'type',
            type: 'text',
            label: 'Element type',
            options: {
                validation: {
                    required: true
                },
                disabled: true
            }
        },
        {
            name: 'name',
            type: 'text',
            label: 'Name',
            options: {
                hint: 'A unique element name',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'label',
            type: 'text',
            label: 'Label',
            options: {
                hint: 'The text the user sees',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'options',
            type: 'panel',
            label: 'Options',
            options: {
                fields: [
                    {
                        name: 'hint',
                        type: 'text',
                        label: 'Hint',
                        options: {
                            hint: 'Give user a hint',
                            validation: {
                                required: false
                            }
                        }
                    },
                    {
                        name: 'showIf',
                        type: 'fieldset',
                        label: 'Show If?',
                        options: {
                            fields: [
                                {
                                    name: 'property',
                                    type: 'text',
                                    label: 'Property name',
                                    options: {
                                        hint:
                                            'Property name of field dependency.',
                                        validation: {
                                            required: false
                                        }
                                    }
                                },
                                {
                                    name: 'value',
                                    type: 'text',
                                    label: 'Property value',
                                    options: {
                                        hint: 'Value of dependent field.',
                                        validation: {
                                            required: false
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    {
                        name: 'validation',
                        type: 'fieldset',
                        label: 'Validation',
                        options: {
                            fields: [
                                {
                                    name: 'requiredMin',
                                    type: 'number',
                                    label:
                                        'Require at least this many to be checked:',
                                    options: {
                                        validation: {
                                            required: false,
                                            min: '0'
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    {
                        name: 'fields',
                        type: 'array',
                        label: 'Fields',
                        options: {
                            fields: [
                                {
                                    name: 'type',
                                    type: 'select',
                                    label: 'Element type',
                                    options: {
                                        validation: {
                                            required: true
                                        },
                                        items: [
                                            {
                                                label: 'checkbox',
                                                value: 'checkbox'
                                            }
                                        ],
                                        disabled: false
                                    }
                                },
                                {
                                    name: 'name',
                                    type: 'text',
                                    label: 'Name',
                                    options: {
                                        hint: 'A unique element name',
                                        validation: {
                                            required: true
                                        }
                                    }
                                },
                                {
                                    name: 'label',
                                    type: 'text',
                                    label: 'Label',
                                    options: {
                                        hint: 'The text the user sees',
                                        validation: {
                                            required: true
                                        }
                                    }
                                },
                                {
                                    name: 'options',
                                    type: 'panel',
                                    label: 'Options',
                                    options: {
                                        fields: [
                                            {
                                                name: 'align',
                                                type: 'radio',
                                                label: 'Align box to...',
                                                options: {
                                                    align: 'after',
                                                    vertical: true,
                                                    validation: {
                                                        required: false
                                                    },
                                                    items: [
                                                        {
                                                            label: 'Start',
                                                            value: 'start'
                                                        },
                                                        {
                                                            label: 'End',
                                                            value: 'end'
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                name: 'disabled',
                                                type: 'radio',
                                                label: 'Default state',
                                                options: {
                                                    align: 'after',
                                                    vertical: true,
                                                    validation: {
                                                        required: false
                                                    },
                                                    items: [
                                                        {
                                                            label: 'Disabled',
                                                            value: true
                                                        },
                                                        {
                                                            label: 'Enabled',
                                                            value: false
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                name: 'specify',
                                                type: 'panel',
                                                label: 'Other specify',
                                                options: {
                                                    fields: [
                                                        {
                                                            name: 'type',
                                                            type: 'select',
                                                            label:
                                                                'Element type',
                                                            options: {
                                                                validation: {
                                                                    required: false
                                                                },
                                                                items: [
                                                                    {
                                                                        label:
                                                                            'text',
                                                                        value:
                                                                            'text'
                                                                    }
                                                                ],
                                                                disabled: false
                                                            }
                                                        },
                                                        {
                                                            name: 'name',
                                                            type: 'text',
                                                            label: 'Name',
                                                            options: {
                                                                hint:
                                                                    'A unique element name',
                                                                validation: {
                                                                    required: false
                                                                }
                                                            }
                                                        },
                                                        {
                                                            name: 'label',
                                                            type: 'text',
                                                            label: 'Label',
                                                            options: {
                                                                hint:
                                                                    'The text the user sees',
                                                                validation: {
                                                                    required: false
                                                                }
                                                            }
                                                        },
                                                        {
                                                            name: 'options',
                                                            type: 'panel',
                                                            label: 'Options',
                                                            options: {
                                                                fields: [
                                                                    {
                                                                        name:
                                                                            'hint',
                                                                        type:
                                                                            'text',
                                                                        label:
                                                                            'Hint',
                                                                        options: {
                                                                            hint:
                                                                                'Give the user a hint',
                                                                            validation: {
                                                                                required: false
                                                                            }
                                                                        }
                                                                    },

                                                                    {
                                                                        name:
                                                                            'validation',
                                                                        type:
                                                                            'fieldset',
                                                                        label:
                                                                            'Validation',
                                                                        options: {
                                                                            fields: [
                                                                                {
                                                                                    name:
                                                                                        'requiredIf',
                                                                                    type:
                                                                                        'fieldset',
                                                                                    label:
                                                                                        'Required If?',
                                                                                    options: {
                                                                                        fields: [
                                                                                            {
                                                                                                name:
                                                                                                    'property',
                                                                                                type:
                                                                                                    'text',
                                                                                                label:
                                                                                                    'Property name',
                                                                                                options: {
                                                                                                    hint:
                                                                                                        'Property name of field dependency.',
                                                                                                    validation: {
                                                                                                        required: false
                                                                                                    }
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                name:
                                                                                                    'value',
                                                                                                type:
                                                                                                    'text',
                                                                                                label:
                                                                                                    'Property value',
                                                                                                options: {
                                                                                                    hint:
                                                                                                        'Value of dependent field.',
                                                                                                    validation: {
                                                                                                        required: false
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                name: 'validation',
                                                type: 'fieldset',
                                                label: 'Validation',
                                                options: {
                                                    fields: [
                                                        {
                                                            name: 'required',
                                                            type: 'checkbox',
                                                            label: 'Required?',
                                                            options: {
                                                                align: 'after',
                                                                validation: {
                                                                    required: false
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ];
    entity: any = {
        type: 'checkbox-group',
        options: {
            validation: {
                requiredMin: 0
            },
            fields: [
                {
                    options: {
                        validation: {
                            disabled: false,
                            align: 'after'
                        }
                    }
                }
            ]
        }
    };
}
