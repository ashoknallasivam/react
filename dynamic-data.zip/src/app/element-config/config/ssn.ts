import { TextMaskConfig } from './text-mask';

export class SsnConfig {

  static hint = 'xxx-xx-xxxx';
  static inputMask = '000-00-0000';
  static pattern =
    '^(?!219-09-9999|219099999|078-05-1120|078051120)(?!666|000|9\\d{2})\\d{3}-?(?!00)\\d{2}-?(?!0{4})\\d{4}$';
  static patternValMsg =
    'Invalid SSN entered. Visit the <a href="https://secure.ssa.gov/poms.nsf/lnx/0110201035" ' +
    'target="_blank">Social Security Admnistration</a> for more information.';
  layout: any;
  entity: any = {
    type: 'ssn',
  };
  constructor() {
    this.layout = new TextMaskConfig().layout;
    this.layout.map((f) => {
      if (f.type === 'heading') {
        f.label = 'SSN configuration';
      }
      if (f.name === 'options') {
        f.options.fields.map((o) => {
          if (o.name === 'hint' || o.name === 'inputMask') {
            o.options.disabled = true;
          }
          if (o.name === 'validation') {
            o.options.fields.map((v) => {
              if (v.name === 'pattern' || v.name === 'patternValMsg') {
                v.options.disabled = true;
              }
            });
          }
        });
      }
    });
  }
}
