export class PanelConfig {
  layout: any = [
    {
      type: 'heading',
      label: 'Panel configuration',
      options: {
        level: 1,
      },
    },
    {
      name: 'type',
      type: 'text',
      label: 'Element type',
      options: {
        validation: {
          required: true,
        },
        disabled: true,
      },
    },
    {
      name: 'name',
      type: 'text',
      label: 'Name',
      options: {
        hint: 'A unique element name',
        validation: {
          required: true,
        },
      },
    },
    {
      name: 'label',
      type: 'text',
      label: 'Label',
      options: {
        hint: 'The text the user sees',
        validation: {
          required: true,
        },
      },
    },
    {
      name: 'options',
      type: 'panel',
      label: 'Options',
      options: {
        fields: [
          {
            name: 'hint',
            type: 'text',
            label: 'Hint',
            options: {
              hint: 'Give user a hint',
              validation: {
                required: false,
              },
            },
          },
        ],
      },
    },
  ];
  entity: any = {
    type: 'panel',
  };
}
