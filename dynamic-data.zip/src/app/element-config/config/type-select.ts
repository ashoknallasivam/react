export class TypeSelectConfig {
  layout: any = [
    {
      type: 'select',
      name: 'elementType',
      label: 'Element type',
      options: {
        hint: 'Select element type',
        validation: { required: true },
        items: [
          {
            value: 'action-toolbar',
            label: 'action-toolbar',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'address',
            label: 'address',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'array',
            label: 'array',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'button',
            label: 'button',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'checkbox-group',
            label: 'checkbox-group',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'checkbox',
            label: 'checkbox',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'date',
            label: 'date',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'email',
            label: 'email',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'fieldset',
            label: 'fieldset',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'heading',
            label: 'heading',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'number',
            label: 'number',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'panel',
            label: 'panel',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'password',
            label: 'password',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'phone',
            label: 'phone',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'radio',
            label: 'radio',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'select',
            label: 'select',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'slide-toggle',
            label: 'slide-toggle',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'slider',
            label: 'slider',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'ssn',
            label: 'ssn',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'states',
            label: 'states',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'static',
            label: 'static',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'text-mask',
            label: 'text-mask',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'text',
            label: 'text',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'textarea',
            label: 'textarea',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },

          {
            value: 'time',
            label: 'time',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
          {
            value: 'zip',
            label: 'zip',
            options: {
              specify: {
                options: {
                  validation: {},
                },
              },
            },
          },
        ],
      },
    },
  ];
}
