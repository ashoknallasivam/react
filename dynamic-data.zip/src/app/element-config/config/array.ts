export class ArrayConfig {
    layout: any = [
        {
            type: 'heading',
            label: 'Array configuration',
            options: {
                level: 1
            }
        },
        {
            name: 'type',
            type: 'text',
            label: 'Element type',
            options: {
                validation: {
                    required: true
                },
                disabled: true
            }
        },
        {
            name: 'name',
            type: 'text',
            label: 'Name',
            options: {
                hint: 'A unique element name',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'label',
            type: 'text',
            label: 'Label',
            options: {
                hint: 'The text the user sees',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'options',
            type: 'panel',
            label: 'Options',
            options: {
                fields: [
                    {
                        name: 'hint',
                        type: 'text',
                        label: 'Hint',
                        options: {
                            hint: 'Give user a hint',
                            validation: {
                                required: false
                            }
                        }
                    },
                    {
                        name: 'addText',
                        type: 'text',
                        label: 'Add button text',
                        options: {
                            hint: 'Provide meaningful button text',
                            validation: {
                                required: false
                            }
                        }
                    },
                    {
                        name: 'removeText',
                        type: 'text',
                        label: 'Remove button text',
                        options: {
                            hint: 'Provide meaningful button text',
                            validation: {
                                required: false
                            }
                        }
                    },
                    {
                        name: 'defaultEmpty',
                        type: 'checkbox',
                        label: 'Default to empty array?',
                        options: {
                            align: 'after',
                            validation: {
                                required: false
                            }
                        }
                    },
                    {
                        name: 'validation',
                        type: 'fieldset',
                        label: 'Validation',
                        options: {
                            fields: [
                                {
                                    name: 'required',
                                    type: 'checkbox',
                                    label: 'Required?',
                                    options: {
                                        align: 'after',
                                        validation: {
                                            required: false
                                        }
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ];
    entity: any = {
        type: 'array'
    };
}
