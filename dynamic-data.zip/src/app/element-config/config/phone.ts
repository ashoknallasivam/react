import { TextMaskConfig } from './text-mask';

export class PhoneConfig {

  static hint = '(xxx) xxx-xxxx';
  static inputMask = '(000) 000-0000';
  static pattern = '\\d{10}';
  static patternValMsg = 'Phone must be 10 digits';
  layout: any;
  entity: any = {
    type: 'phone',
  };
  constructor() {
    this.layout = new TextMaskConfig().layout;
    this.layout.map((f) => {
      if (f.type === 'heading') {
        f.label = 'Phone configuration';
      }
      if (f.name === 'options') {
        f.options.fields.map((o) => {
          if (o.name === 'hint' || o.name === 'inputMask') {
            o.options.disabled = true;
          }
          if (o.name === 'validation') {
            o.options.fields.map((v) => {
              if (v.name === 'pattern' || v.name === 'patternValMsg') {
                v.options.disabled = true;
              }
            });
          }
        });
      }
    });
  }
}
