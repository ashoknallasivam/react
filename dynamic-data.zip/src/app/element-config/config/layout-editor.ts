export class LayoutEditorConfig {
  layout: any = {
    type: 'layout-editor',
    name: 'fields',
    options: {
      fields: [],
    },
  };
}
