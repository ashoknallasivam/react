export class FieldsetConfig {
  layout: any = [
    {
      type: 'heading',
      label: 'Fieldset configuration',
      options: {
        level: 1,
      },
    },
    {
      name: 'type',
      type: 'text',
      label: 'Element type',
      options: {
        validation: {
          required: true,
        },
        disabled: true,
      },
    },
    {
      name: 'name',
      type: 'text',
      label: 'Name',
      options: {
        hint: 'A unique element name',
        validation: {
          required: true,
        },
      },
    },
    {
      name: 'label',
      type: 'text',
      label: 'Label',
      options: {
        hint: 'The text the user sees',
        validation: {
          required: true,
        },
      },
    },
    {
      name: 'options',
      type: 'panel',
      label: 'Options',
      options: {
        fields: [],
      },
    },
  ];
  entity: any = {
    type: 'fieldset',
  };
}
