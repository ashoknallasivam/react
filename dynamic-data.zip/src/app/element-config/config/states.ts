import { SelectConfig } from './select';

export class StatesConfig {
    static states: any[] = [
        {
            value: 'AL',
            label: 'Alabama',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'AK',
            label: 'Alaska',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'AZ',
            label: 'Arizona',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'AR',
            label: 'Arkansas',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'CA',
            label: 'California',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'CO',
            label: 'Colorado',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'CT',
            label: 'Connecticut',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'DE',
            label: 'Delaware',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'DC',
            label: 'District of Columbia',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'FL',
            label: 'Florida',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'GA',
            label: 'Georgia',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'HI',
            label: 'Hawaii',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'ID',
            label: 'Idaho',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'IL',
            label: 'Illinois',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'IN',
            label: 'Indiana',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'IA',
            label: 'Iowa',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'KS',
            label: 'Kansas',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'KY',
            label: 'Kentucky',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'LA',
            label: 'Louisiana',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'ME',
            label: 'Maine',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'MD',
            label: 'Maryland',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'MA',
            label: 'Massachusetts',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'MI',
            label: 'Michigan',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'MN',
            label: 'Minnesota',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'MS',
            label: 'Mississippi',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'MO',
            label: 'Missouri',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'MT',
            label: 'Montana',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'NE',
            label: 'Nebraska',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'NV',
            label: 'Nevada',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'NH',
            label: 'New Hampshire',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'NJ',
            label: 'New Jersey',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'NM',
            label: 'New Mexico',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'NY',
            label: 'New York',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'NC',
            label: 'North Carolina',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'ND',
            label: 'North Dakota',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'OH',
            label: 'Ohio',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'OK',
            label: 'Oklahoma',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'OR',
            label: 'Oregon',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'PA',
            label: 'Pennsylvania',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'RI',
            label: 'Rhode Island',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'SC',
            label: 'South Carolina',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'SD',
            label: 'South Dakota',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'TN',
            label: 'Tennessee',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'TX',
            label: 'Texas',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'UT',
            label: 'Utah',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'VT',
            label: 'Vermont',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'VA',
            label: 'Virginia',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'WA',
            label: 'Washington',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'WV',
            label: 'West Virginia',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'WI',
            label: 'Wisconsin',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        },
        {
            value: 'WY',
            label: 'Wyoming',
            options: {
                specify: {
                    options: {
                        validation: {
                            requiredIf: {}
                        }
                    }
                }
            }
        }
    ];
    layout: any = [
        {
            type: 'heading',
            label: 'States configuration',
            options: {
                level: 1
            }
        },
        {
            name: 'type',
            type: 'text',
            label: 'Element type',
            options: {
                validation: {
                    required: true
                },
                disabled: true
            }
        },
        {
            name: 'name',
            type: 'text',
            label: 'Name',
            options: {
                hint: 'A unique element name',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'label',
            type: 'text',
            label: 'Label',
            options: {
                hint: 'What the user sees',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'options',
            type: 'panel',
            label: 'Options',
            options: {
                fields: [
                    {
                        name: 'hint',
                        type: 'text',
                        label: 'Hint',
                        options: {
                            validation: {
                                required: false
                            },
                            hint: 'Provide additional instructions if necessary'
                        }
                    },
                    {
                        name: 'defaultValue',
                        type: 'text',
                        label: 'Default value',
                        options: {
                            validation: {
                                required: false
                            },
                            hint: 'Provide a default value'
                        }
                    },
                    {
                        name: 'showIf',
                        type: 'fieldset',
                        label: 'Show If?',
                        options: {
                            fields: [
                                {
                                    name: 'property',
                                    type: 'text',
                                    label: 'Property name',
                                    options: {
                                        hint:
                                            'Property name of field dependency.',
                                        validation: {
                                            required: false
                                        }
                                    }
                                },
                                {
                                    name: 'value',
                                    type: 'text',
                                    label: 'Property value',
                                    options: {
                                        hint: 'Value of dependent field.',
                                        validation: {
                                            required: false
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    {
                        name: 'validation',
                        type: 'fieldset',
                        label: 'Validation',
                        options: {
                            fields: [
                                {
                                    name: 'required',
                                    type: 'checkbox',
                                    label: 'Required?',
                                    options: {
                                        align: 'after',
                                        validation: {
                                            required: false
                                        }
                                    }
                                },
                                {
                                    name: 'requiredIf',
                                    type: 'fieldset',
                                    label: 'Required If?',
                                    options: {
                                        fields: [
                                            {
                                                name: 'property',
                                                type: 'text',
                                                label: 'Property name',
                                                options: {
                                                    hint:
                                                        'Property name of field dependency.',
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            },
                                            {
                                                name: 'value',
                                                type: 'text',
                                                label: 'Property value',
                                                options: {
                                                    hint:
                                                        'Value of dependent field.',
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ];
    entity: any = {
        type: 'states'
    };
}
