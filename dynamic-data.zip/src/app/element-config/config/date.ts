export class DateConfig {
    layout: any = [
        {
            type: 'heading',
            label: 'Date configuration',
            options: {
                level: 1
            }
        },
        {
            name: 'type',
            type: 'text',
            label: 'Element type',
            options: {
                validation: {
                    required: true
                },
                disabled: true
            }
        },
        {
            name: 'name',
            type: 'text',
            label: 'Name',
            options: {
                hint: 'A unique element name',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'label',
            type: 'text',
            label: 'Label',
            options: {
                hint: 'The text the user sees',
                validation: {
                    required: true
                }
            }
        },
        {
            name: 'options',
            type: 'panel',
            label: 'Options',
            options: {
                fields: [
                    {
                        name: 'hint',
                        type: 'text',
                        label: 'Hint',
                        options: {
                            hint: 'Give user a hint',
                            validation: {
                                required: false
                            }
                        }
                    },
                    {
                        name: 'defaultValue',
                        type: 'text',
                        label: 'Default value',
                        options: {
                            validation: {
                                required: false
                            },
                            hint: 'Provide a default value (ISO date format)'
                        }
                    },
                    {
                        name: 'showIf',
                        type: 'fieldset',
                        label: 'Show If?',
                        options: {
                            fields: [
                                {
                                    name: 'property',
                                    type: 'text',
                                    label: 'Property name',
                                    options: {
                                        hint:
                                            'Property name of field dependency.',
                                        validation: {
                                            required: false
                                        }
                                    }
                                },
                                {
                                    name: 'value',
                                    type: 'text',
                                    label: 'Property value',
                                    options: {
                                        hint: 'Value of dependent field.',
                                        validation: {
                                            required: false
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    {
                        name: 'startAt',
                        type: 'panel',
                        label: 'Start date',
                        options: {
                            fields: [
                                {
                                    name: 'year',
                                    type: 'number',
                                    label: 'Year',
                                    options: {
                                        hint: 'The start year',
                                        validation: {
                                            required: false
                                        }
                                    }
                                },
                                {
                                    name: 'month',
                                    type: 'select',
                                    label: 'Month',
                                    options: {
                                        hint: 'The start month',
                                        items: [
                                            {
                                                value: '0',
                                                label: 'January'
                                            },
                                            {
                                                value: '1',
                                                label: 'February'
                                            },
                                            {
                                                value: '2',
                                                label: 'March'
                                            },
                                            {
                                                value: '3',
                                                label: 'April'
                                            },
                                            {
                                                value: '4',
                                                label: 'May'
                                            },
                                            {
                                                value: '5',
                                                label: 'June'
                                            },
                                            {
                                                value: '6',
                                                label: 'July'
                                            },
                                            {
                                                value: '7',
                                                label: 'August'
                                            },
                                            {
                                                value: '8',
                                                label: 'September'
                                            },
                                            {
                                                value: '9',
                                                label: 'October'
                                            },
                                            {
                                                value: '10',
                                                label: 'November'
                                            },
                                            {
                                                value: '11',
                                                label: 'December'
                                            }
                                        ],
                                        validation: {
                                            required: false
                                        }
                                    }
                                },
                                {
                                    name: 'day',
                                    type: 'number',
                                    label: 'Day',
                                    options: {
                                        hint: 'The start day',
                                        validation: {
                                            required: false,
                                            min: 1,
                                            max: 31
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    {
                        name: 'validation',
                        type: 'fieldset',
                        label: 'Validation',
                        options: {
                            fields: [
                                {
                                    name: 'required',
                                    type: 'checkbox',
                                    label: 'Required?',
                                    options: {
                                        align: 'after',
                                        validation: {
                                            required: false
                                        }
                                    }
                                },
                                {
                                    name: 'minDate',
                                    type: 'panel',
                                    label: 'Minimum date',
                                    options: {
                                        fields: [
                                            {
                                                name: 'year',
                                                type: 'number',
                                                label: 'Year',
                                                options: {
                                                    hint:
                                                        'The minimum date year',
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            },
                                            {
                                                name: 'month',
                                                type: 'select',
                                                label: 'Month',
                                                options: {
                                                    hint:
                                                        'The minimum date month',
                                                    items: [
                                                        {
                                                            value: '0',
                                                            label: 'January'
                                                        },
                                                        {
                                                            value: '1',
                                                            label: 'February'
                                                        },
                                                        {
                                                            value: '2',
                                                            label: 'March'
                                                        },
                                                        {
                                                            value: '3',
                                                            label: 'April'
                                                        },
                                                        {
                                                            value: '4',
                                                            label: 'May'
                                                        },
                                                        {
                                                            value: '5',
                                                            label: 'June'
                                                        },
                                                        {
                                                            value: '6',
                                                            label: 'July'
                                                        },
                                                        {
                                                            value: '7',
                                                            label: 'August'
                                                        },
                                                        {
                                                            value: '8',
                                                            label: 'September'
                                                        },
                                                        {
                                                            value: '9',
                                                            label: 'October'
                                                        },
                                                        {
                                                            value: '10',
                                                            label: 'November'
                                                        },
                                                        {
                                                            value: '11',
                                                            label: 'December'
                                                        }
                                                    ],
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            },
                                            {
                                                name: 'day',
                                                type: 'number',
                                                label: 'Day',
                                                options: {
                                                    hint:
                                                        'The minimum date day',
                                                    validation: {
                                                        required: false,
                                                        min: 1,
                                                        max: 31
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    name: 'maxDate',
                                    type: 'panel',
                                    label: 'Maximum date',
                                    options: {
                                        fields: [
                                            {
                                                name: 'year',
                                                type: 'number',
                                                label: 'Year',
                                                options: {
                                                    hint:
                                                        'The maximum date year',
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            },
                                            {
                                                name: 'month',
                                                type: 'select',
                                                label: 'Month',
                                                options: {
                                                    hint:
                                                        'The maximum date month',
                                                    items: [
                                                        {
                                                            value: '0',
                                                            label: 'January'
                                                        },
                                                        {
                                                            value: '1',
                                                            label: 'February'
                                                        },
                                                        {
                                                            value: '2',
                                                            label: 'March'
                                                        },
                                                        {
                                                            value: '3',
                                                            label: 'April'
                                                        },
                                                        {
                                                            value: '4',
                                                            label: 'May'
                                                        },
                                                        {
                                                            value: '5',
                                                            label: 'June'
                                                        },
                                                        {
                                                            value: '6',
                                                            label: 'July'
                                                        },
                                                        {
                                                            value: '7',
                                                            label: 'August'
                                                        },
                                                        {
                                                            value: '8',
                                                            label: 'September'
                                                        },
                                                        {
                                                            value: '9',
                                                            label: 'October'
                                                        },
                                                        {
                                                            value: '10',
                                                            label: 'November'
                                                        },
                                                        {
                                                            value: '11',
                                                            label: 'December'
                                                        }
                                                    ],
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            },
                                            {
                                                name: 'day',
                                                type: 'number',
                                                label: 'Day',
                                                options: {
                                                    hint:
                                                        'The maximum date day',
                                                    validation: {
                                                        required: false,
                                                        min: 1,
                                                        max: 31
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    name: 'requiredIf',
                                    type: 'fieldset',
                                    label: 'Required If?',
                                    options: {
                                        fields: [
                                            {
                                                name: 'property',
                                                type: 'text',
                                                label: 'Property name',
                                                options: {
                                                    hint:
                                                        'Property name of field dependency.',
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            },
                                            {
                                                name: 'value',
                                                type: 'text',
                                                label: 'Property value',
                                                options: {
                                                    hint:
                                                        'Value of dependent field.',
                                                    validation: {
                                                        required: false
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ];
    entity: any = {
        type: 'date'
    };
}
