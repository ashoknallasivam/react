export class StaticConfig {
  layout: any = [
    {
      type: 'heading',
      label: 'Static text configuration',
      options: {
        level: 1,
      },
    },
    {
      name: 'type',
      type: 'text',
      label: 'Element type',
      options: {
        validation: {
          required: true,
        },
        disabled: true,
      },
    },
    {
      name: 'label',
      type: 'textarea',
      label: 'Label',
      options: {
        hint: 'What the user sees',
        validation: {
          required: true,
        },
      },
    },
    {
      name: 'options',
      type: 'panel',
      label: 'Options',
      options: {
        fields: [
          {
            name: 'showIf',
            type: 'fieldset',
            label: 'Show If?',
            options: {
              fields: [
                {
                  name: 'property',
                  type: 'text',
                  label: 'Property name',
                  options: {
                    hint: 'Property name of field dependency.',
                    validation: {
                      required: false,
                    },
                  },
                },
                {
                  name: 'value',
                  type: 'text',
                  label: 'Property value',
                  options: {
                    hint: 'Value of dependent field.',
                    validation: {
                      required: false,
                    },
                  },
                },
              ],
            },
          },
        ],
      },
    },
  ];
  entity: any = {
    type: 'static',
  };
}
