import { TextMaskConfig } from './text-mask';

export class TimeConfig {

  static hint = 'hh:mm AM|PM';
  static inputMask = '00:00 SS';
  static pattern = '^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]\\s(AM|am|PM|pm)$';
  static patternValMsg = 'Invalid Time format.';
  layout: any;
  entity: any = {
    type: 'time',
  };
  constructor() {
    this.layout = new TextMaskConfig().layout;
    this.layout.map((f) => {
      if (f.type === 'heading') {
        f.label = 'Time configuration';
      }
      if (f.name === 'options') {
        f.options.fields.map((o) => {
          if (o.name === 'hint' || o.name === 'inputMask') {
            o.options.disabled = true;
          }
          if (o.name === 'validation') {
            o.options.fields.map((v) => {
              if (v.name === 'pattern' || v.name === 'patternValMsg') {
                v.options.disabled = true;
              }
            });
          }
        });
      }
    });
  }
}
