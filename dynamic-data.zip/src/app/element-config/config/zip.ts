import { TextMaskConfig } from './text-mask';

export class ZipConfig {

  static hint = 'xxxxx-xxxx';
  static inputMask = '00000-0000';
  static pattern = '^\\d{5}(\\d{4})?$';
  static patternValMsg = 'Zip must be 5 or 9 digits';
  layout: any;
  entity: any = {
    type: 'zip',
  };
  constructor() {
    this.layout = new TextMaskConfig().layout;
    this.layout.map((f) => {
      if (f.type === 'heading') {
        f.label = 'Zip configuration';
      }
      if (f.name === 'options') {
        f.options.fields.map((o) => {
          if (o.name === 'hint' || o.name === 'inputMask') {
            o.options.disabled = true;
          }
          if (o.name === 'validation') {
            o.options.fields.map((v) => {
              if (v.name === 'pattern' || v.name === 'patternValMsg') {
                v.options.disabled = true;
              }
            });
          }
        });
      }
    });
  }
}
