import { FormGroup } from '@angular/forms';

export class RequiredMinimumValidator {
  public validate: () => any;

  constructor(min: number) {
    // set up function w/ min param, store for future use
    this.validate = this.validateRequiredMin(min);
  }

  validateRequiredMin(min: number): any {
    return (group: FormGroup) => {
      if (!group || !group.controls) {
        return null;
      }

      const count = Object.keys(group.controls)
        .map(name => group.get(name))
        .filter(item => item.value).length;

      return count < min
        ? { requiredMin: { required: min, actual: count } }
        : null;
    };
  }
}
