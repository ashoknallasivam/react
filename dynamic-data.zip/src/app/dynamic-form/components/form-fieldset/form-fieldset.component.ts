import { Component } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-fieldset',
  templateUrl: './form-fieldset.component.html',
  styleUrls: ['./form-fieldset.component.css']
})
export class FormFieldSetComponent extends DynamicBaseComponent {}
