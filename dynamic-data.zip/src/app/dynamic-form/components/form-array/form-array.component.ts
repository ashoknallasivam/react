import { Component, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';

import { DynamicFormBuilder } from '../../dynamic-form-builder';
import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-array',
  templateUrl: './form-array.component.html',
  styleUrls: ['./form-array.component.css']
})
export class FormArrayComponent extends DynamicBaseComponent implements OnInit {
  fb: DynamicFormBuilder;
  array: FormArray;

  ngOnInit() {
    this.fb = new DynamicFormBuilder();
    this.array = this.group.get(this.config.name) as FormArray;
    super.ngOnInit();
  }

  add() {
    this.array.push(this.fb.createGroup(this.config));
    this.array.markAsTouched();
  }

  remove(index) {
    this.array.removeAt(index);
    this.array.markAsTouched();
  }
}
