import { Component } from '@angular/core';

import { EmailConfig } from '../../../element-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-email',
  templateUrl: './form-email.component.html',
  styleUrls: ['./form-email.component.css']
})
export class FormEmailComponent extends DynamicBaseComponent {
  pattern(): string {
    return EmailConfig.pattern;
  }
}
