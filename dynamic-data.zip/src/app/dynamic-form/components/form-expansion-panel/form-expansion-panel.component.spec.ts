import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormExpansionPanelComponent } from './form-expansion-panel.component';

describe('FormExpansionPanelComponent', () => {
  let component: FormExpansionPanelComponent;
  let fixture: ComponentFixture<FormExpansionPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FormExpansionPanelComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormExpansionPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
