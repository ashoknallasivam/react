import { Component } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-expansion-panel',
  templateUrl: './form-expansion-panel.component.html',
  styleUrls: ['./form-expansion-panel.component.css']
})
export class FormExpansionPanelComponent extends DynamicBaseComponent {}
