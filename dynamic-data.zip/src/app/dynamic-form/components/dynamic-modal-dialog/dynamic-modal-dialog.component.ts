import { Component, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import { DialogButtons } from '../../enumerations/dialog-buttons';
import { DialogConfig } from '../../interfaces/dialog-config';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';

@Component({
  selector: 'dynamic-dynamic-modal-dialog',
  templateUrl: './dynamic-modal-dialog.component.html',
  styleUrls: ['./dynamic-modal-dialog.component.css']
})
export class DynamicModalDialogComponent {
  @ViewChild('form')
  modalForm: DynamicFormComponent;
  primaryButtonText = 'Submit';
  secondaryButtonText = 'Cancel';
  returnValue?: boolean;

  constructor(
    public dialogRef: MatDialogRef<DynamicModalDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogConfig
  ) {
    if (!data.preformattedJson) {
      data.preformattedJson = false;
    }

    switch (data.dialogButtons) {
      case DialogButtons.OK:
      case DialogButtons.OKCancel:
        this.primaryButtonText = 'OK';
        this.returnValue = true;
        break;
      case DialogButtons.NextCancel:
        this.primaryButtonText = 'Next';
        break;
      case DialogButtons.SaveCancel:
        this.primaryButtonText = 'Save';
        break;
      case DialogButtons.YesNo:
        this.primaryButtonText = 'Yes';
        this.secondaryButtonText = 'No';
        this.returnValue = true;
        break;
    }
  }

  checkValidity(): boolean {
    return (
      this.data.dialogButtons === DialogButtons.NextCancel ||
      this.data.dialogButtons === DialogButtons.SaveCancel ||
      this.data.dialogButtons === DialogButtons.SubmitCancel
    );
  }

  displayCancel(): boolean {
    return this.data.dialogButtons !== DialogButtons.OK;
  }

  cancel(): void {
    if (
      this.data.dialogButtons === DialogButtons.OKCancel ||
      this.data.dialogButtons === DialogButtons.YesNo
    ) {
      return this.dialogRef.close(false);
    }
    this.dialogRef.close();
  }
}
