import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicModalDialogComponent } from './dynamic-modal-dialog.component';

describe('DynamicModalDialogComponent', () => {
  let component: DynamicModalDialogComponent;
  let fixture: ComponentFixture<DynamicModalDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DynamicModalDialogComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicModalDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
