import { Component } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-number',
  templateUrl: './form-number.component.html',
  styleUrls: ['./form-number.component.css']
})
export class FormNumberComponent extends DynamicBaseComponent {}
