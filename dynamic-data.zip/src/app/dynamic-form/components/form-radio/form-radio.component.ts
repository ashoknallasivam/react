import { Component, OnInit } from '@angular/core';

import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-radio',
  templateUrl: './form-radio.component.html',
  styleUrls: ['./form-radio.component.css']
})
export class FormRadioComponent extends DynamicBaseComponent implements OnInit {
  width = 100;
  isList = false;

  ngOnInit(): void {
    this.isList = this.config.options.items.length > 1;
    super.ngOnInit();
  }

  specifyConfig(value: string): FieldConfig {
    const selected = this.config.options.items.find(
      item => item.value === value
    );

    return selected &&
      selected.options &&
      selected.options.specify &&
      selected.options.specify.type &&
      selected.options.specify.name
      ? selected.options.specify
      : undefined;
  }

  change() {
    // clear any spec values unrelated to current selection
    const value = this.group.get(this.config.name).value;
    this.config.options.items
      .filter(item => item.value !== value)
      .forEach(item => {
        const spec = this.specifyConfig(item.value);
        if (spec && this.group.get(spec.name)) {
          this.group.get(spec.name).reset();
          this.group.get(spec.name).disable();
        }
      });

    this.config.options.items
      .filter(item => item.value === value)
      .forEach(item => {
        const spec = this.specifyConfig(item.value);
        if (spec && this.group.get(spec.name)) {
          this.group.get(spec.name).enable();
        }
      });
  }
}
