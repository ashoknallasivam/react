import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ElementToolbarComponent } from './action-toolbar.component';

describe('ElementToolbarComponent', () => {
  let component: ElementToolbarComponent;
  let fixture: ComponentFixture<ElementToolbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ElementToolbarComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ElementToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
