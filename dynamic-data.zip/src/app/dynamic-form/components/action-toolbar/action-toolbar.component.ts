import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { ActionButtons } from '../../enumerations/action-buttons';
import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';

@Component({
  selector: 'dynamic-action-toolbar',
  templateUrl: './action-toolbar.component.html',
  styleUrls: ['./action-toolbar.component.css'],
})
export class ActionToolbarComponent implements Field {
  config: FieldConfig;
  group: FormGroup;

  getActionButtonEnum(button: string) {
    switch (button) {
      case 'cancel':
        return ActionButtons.Cancel;
      case 'delete':
        return ActionButtons.Delete;
      case 'submit':
        return ActionButtons.Submit;
    }
  }

  getButtonText(button: string) {
    switch (this.getActionButtonEnum(button)) {
      case ActionButtons.Cancel:
        return this.config.options.buttons.cancelButtonText
          ? this.config.options.buttons.cancelButtonText
          : 'Cancel';
      case ActionButtons.Delete:
        return this.config.options.buttons.deleteButtonText
          ? this.config.options.buttons.deleteButtonText
          : 'Delete';
      case ActionButtons.Submit:
        return this.config.options.buttons.submitButtonText
          ? this.config.options.buttons.submitButtonText
          : 'Submit';
    }
  }
}
