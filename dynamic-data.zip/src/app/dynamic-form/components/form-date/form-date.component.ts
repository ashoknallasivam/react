import { Component, OnInit } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
    selector: 'dynamic-form-date',
    templateUrl: './form-date.component.html',
    styleUrls: ['./form-date.component.css']
})
export class FormDateComponent extends DynamicBaseComponent implements OnInit {
    startAt?: Date;
    minDate?: Date;
    maxDate?: Date;
    minDateString?: string;
    maxDateString?: string;

    ngOnInit(): void {
        this.startAt = this.buildDate(this.config.options.startAt);
        this.minDate = this.buildDate(this.config.options.validation.minDate);
        this.maxDate = this.buildDate(this.config.options.validation.maxDate);
        this.minDateString = this.formatDateString(this.minDate);
        this.maxDateString = this.formatDateString(this.maxDate);
        super.ngOnInit();
    }

    buildDate(attr) {
        return attr && attr.year && attr.month && attr.day
            ? new Date(attr.year, attr.month, attr.day)
            : undefined;
    }

    formatDateString(date: Date): string {
        // TODO: allow for other date formats
        return (
            date &&
            `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`
        );
    }

    dateFilter(d: Date): boolean {
        return true;
        // TODO allow custom date validation functions
    }
}
