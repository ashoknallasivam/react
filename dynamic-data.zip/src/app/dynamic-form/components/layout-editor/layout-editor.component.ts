import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';

import { MatDialog } from '@angular/material';

import { ElementConfig } from '../../../element-config/element-config';
import { ElementType } from '../../../element-config/element-type';
import { DynamicFormBuilder } from '../../dynamic-form-builder';
import { DialogButtons } from '../../enumerations/dialog-buttons';
import { DialogConfig } from '../../interfaces/dialog-config';
import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';
import { DynamicModalDialogComponent } from '../dynamic-modal-dialog/dynamic-modal-dialog.component';

@Component({
  selector: 'dynamic-page-editor',
  templateUrl: './layout-editor.component.html',
  styleUrls: ['./layout-editor.component.css']
})
export class LayoutEditorComponent implements Field, OnInit {
  config: FieldConfig;
  group: FormGroup;
  fb: DynamicFormBuilder;
  array: FormArray;

  typeSelectOptions: DialogConfig = {
    heading: 'Add an element',
    size: '400px',
    layout: ElementConfig.getTypeSelection().layout,
    entity: {},
    dialogButtons: DialogButtons.SubmitCancel
  };

  viewSourceOptions: DialogConfig = {
    heading: 'Dynamic Data Generated JSON',
    size: '600px',
    layout: [],
    entity: {},
    dialogButtons: DialogButtons.OK,
    preformattedJson: true
  };

  elementConfigOptions: DialogConfig = {
    heading: 'Element configuration',
    size: '800px',
    layout: [],
    entity: {},
    dialogButtons: DialogButtons.SubmitCancel
  };

  previewOptions: DialogConfig = {
    heading: 'Preview',
    size: '800px',
    layout: [],
    entity: {},
    dialogButtons: DialogButtons.OK
  };

  constructor(public dialog: MatDialog) {}

  ngOnInit() {
    this.fb = new DynamicFormBuilder();
    this.array = this.group.get(this.config.name) as FormArray;
  }

  add(): void {
    // for element type selection
    const typeSelectRef = this.dialog.open(DynamicModalDialogComponent, {
      width: this.typeSelectOptions.size,
      disableClose: true,
      data: this.typeSelectOptions
    });

    typeSelectRef.afterClosed().subscribe(result => {
      if (result && typeof result !== 'boolean') {
        const elementConfig = ElementConfig.get(result.elementType, true);
        this.config.options.fields.push(elementConfig.layout);
        this.array.push(
          this.fb.createGroup(elementConfig.layout, elementConfig.entity)
        );
      }
    });
  }

  viewSource(): void {
    this.viewSourceOptions.entity = this.array.getRawValue();
    this.dialog.open(DynamicModalDialogComponent, {
      width: this.viewSourceOptions.size,
      data: this.viewSourceOptions
    });
  }

  onElementChange(index: number, config: any): void {
    this.config.options.fields[index] = config;
  }

  moveElement(index: number, direction: string): void {
    const moveIndex =
      direction.toLocaleLowerCase() === 'up' ? index - 1 : index + 1;
    const temp = this.config.options.fields[index];
    this.config.options.fields[index] = this.config.options.fields[moveIndex];
    this.config.options.fields[moveIndex] = temp;

    const arrTemp = this.array.controls[index];
    this.array.controls[index] = this.array.controls[moveIndex];
    this.array.controls[moveIndex] = arrTemp;
  }

  remove(index) {
    this.config.options.fields.splice(index, 1);
    this.array.removeAt(index);
  }

  preview() {
    // handle preview
    this.previewOptions.layout = this.array.getRawValue();
    this.dialog.open(DynamicModalDialogComponent, {
      width: this.previewOptions.size,
      data: this.previewOptions
    });
  }

  getElementHeading(elementConfig) {
    if (Array.isArray(elementConfig)) {
      const heading = elementConfig.find(e => e.type === ElementType.Heading);
      if (heading) {
        return heading.label;
      }
    }
    return 'Element configuration';
  }

  getElementLabel(elementConfig, group) {
    if (Array.isArray(elementConfig)) {
      const name = elementConfig.find(e => e.name === 'name');
      if (name && group.value.name) {
        return group.value.name;
      }
    }
    return '';
  }
}
