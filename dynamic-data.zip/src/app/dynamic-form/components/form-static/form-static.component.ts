import { Component } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-static',
  templateUrl: './form-static.component.html',
  styleUrls: ['./form-static.component.css']
})
export class FormStaticComponent extends DynamicBaseComponent {}
