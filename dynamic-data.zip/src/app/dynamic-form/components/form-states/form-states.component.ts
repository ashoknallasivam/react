import { Component, OnInit } from '@angular/core';

import { StatesConfig } from '../../../element-config/config/states';
import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-states',
  templateUrl: './form-states.component.html',
  styleUrls: ['./form-states.component.css']
})
export class FormStatesComponent extends DynamicBaseComponent
  implements OnInit {
  ngOnInit() {
    this.config.options.states = StatesConfig.states;
    super.ngOnInit();
  }
}
