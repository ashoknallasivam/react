/// <reference types="@types/node" />

import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';

import { Field } from '../interfaces/field';
import { FieldConfig } from '../interfaces/field-config';
import { ItemConfig } from '../interfaces/item-config';

import * as uuidv4_ from 'uuid/v4';
// workaround - assign import to a variable to avoid 
// rollup.js error "Cannot call a namespace ('uuidv4')"
const uuid: any = uuidv4_;

export class DynamicBaseComponent implements Field, OnInit {
  id: string;
  config: FieldConfig;
  group: FormGroup;

  constructor() {
    this.id = `ddc-id-${uuid()}`;
  }

  ngOnInit() {
    this.requiredIfChanges();
    this.showIfChanges();
  }

  resetControls(
    config: any,
    disable: boolean = false,
    nestedGroup: FormGroup = null
  ) {
    const group = nestedGroup || this.group;
    if (group.controls[config.name]) {
      if (disable) {
        group.controls[config.name].disable(); // disable to be exempt from validation checks
        group.controls[config.name].reset();
      } else {
        group.controls[config.name].enable();
      }
    }

    if (config.options.fields) {
      config.options.fields.forEach(f => {
        const g: any =
          group.controls[config.name] instanceof FormGroup
            ? group.controls[config.name]
            : null;
        this.resetControls(f, disable, g);
      });
    }

    if (config.options.items) {
      config.options.items.forEach(i => {
        if (i.options && i.options.specify) {
          this.resetControls(i.options.specify, disable);
          this.handleSpecifyConfig(group, i.options.specify, disable);
        }
      });
    }

    if (config.options.specify) {
      this.resetControls(config.options.specify, disable);
      this.handleSpecifyConfig(group, config.options.specify, disable);
    }
  }

  findControl(group: AbstractControl, properties: string[]) {
    // NOTE: this method is still limited to properties within the same FormGroup
    // properties represents the array of a property containing dot notation; i.e. insuranceType.mediCal

    const property: string = properties[0];
    // get the first property and check if it is a FormGroup; i.e. insuranceType
    if (group.get(property) instanceof FormGroup) {
      // check nested FormGroup for the next property within the dot notation; i.e. mediCal
      return this.findControl(group.get(property), properties.slice(1));
    }
    // return the lowest level FormControl with the specified property name
    return group.get(property);
  }

  handleSpecifyConfig(group: FormGroup, spec: any, disable: boolean) {
    if (group.get(spec.name)) {
      group.get(spec.name).disable();
    }
  }

  handleEnableDisable(validation: any, onInit: boolean = false) {
    if (
      !this.requiredIf() ||
      (onInit &&
        this.group.controls[validation.property].value === undefined &&
        this.group.value &&
        this.group.value[validation.property] &&
        this.group.value[validation.property].toString() ===
          validation.value.toString()) ||
      (this.group.controls[validation.property].value &&
        this.group.controls[validation.property].value.toString() !==
          validation.value.toString())
    ) {
      this.resetControls(this.config, true);
    } else {
      this.resetControls(this.config);
    }
  }

  requiredIfChanges() {
    if (!this.config.options || !this.config.options.validation) {
      return;
    }
    const validation = this.config.options.validation.requiredIf;
    if (
      validation &&
      validation.property &&
      this.group.controls[validation.property]
    ) {
      this.handleEnableDisable(validation, true); // check if text component should be disabled onInit
      this.group.controls[validation.property].valueChanges.subscribe(val => {
        this.handleEnableDisable(validation);
      });
    }
  }

  requiredIf(): any {
    const validation = this.config.options.validation.requiredIf;
    let required =
      validation &&
      validation.property &&
      this.group.controls[validation.property] &&
      (!this.group.controls[validation.property].value ||
        (this.group.controls[validation.property].value &&
          validation.value &&
          this.group.controls[validation.property].value.toString() ===
            validation.value.toString()));

    // check parent FormGroup if validation.property does not exist within the FormArray
    if (
      this.group.parent &&
      this.group.parent instanceof FormArray &&
      validation &&
      validation.property &&
      !this.group.controls[validation.property]
    ) {
      const parentGroup: any = this.group.parent.parent;
      required =
        validation &&
        validation.property &&
        parentGroup.controls[validation.property] &&
        (!parentGroup.controls[validation.property].value ||
          (parentGroup.controls[validation.property].value &&
            validation.value &&
            parentGroup.controls[validation.property].value.toString() ===
              validation.value.toString()));
    }

    return required;
  }

  showIfChanges() {
    const showIf =
      this.config.options && this.config.options.showIf
        ? this.config.options.showIf
        : null;
    const ctrl =
      showIf &&
      showIf.property &&
      this.findControl(this.group, showIf.property.split('.'));
    if (ctrl) {
      ctrl.valueChanges.subscribe(val => {
        if (!this.showIf()) {
          this.resetControls(this.config, true);
        } else {
          this.resetControls(this.config);
        }
      });
    }
  }

  showIf(): any {
    const showIf =
      this.config.options && this.config.options.showIf
        ? this.config.options.showIf
        : null;
    const ctrl =
      showIf &&
      showIf.property &&
      this.findControl(this.group, showIf.property.split('.'));
    const show =
      !showIf ||
      (showIf && !showIf.property) ||
      (showIf &&
        showIf.property &&
        ctrl &&
        (ctrl.value &&
          showIf.value &&
          ctrl.value.toString() === showIf.value.toString()));
    return show;
  }
}
