import { Component } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-slider',
  templateUrl: './form-slider.component.html',
  styleUrls: ['./form-slider.component.css']
})
export class FormSliderComponent extends DynamicBaseComponent {}
