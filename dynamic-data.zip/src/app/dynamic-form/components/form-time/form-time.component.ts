import { Component } from '@angular/core';

import { TimeConfig } from '../../../element-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-time',
  templateUrl: './form-time.component.html',
  styleUrls: ['./form-time.component.css']
})
export class FormTimeComponent extends DynamicBaseComponent {
  hint(): string {
    return TimeConfig.hint;
  }
  inputMask(): string {
    return TimeConfig.inputMask;
  }
  pattern(): string {
    return TimeConfig.pattern;
  }
  patternValidationMessage(): string {
    return TimeConfig.patternValMsg;
  }
}
