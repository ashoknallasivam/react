import { Component } from '@angular/core';

import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-select',
  templateUrl: './form-select.component.html',
  styleUrls: ['./form-select.component.css']
})
export class FormSelectComponent extends DynamicBaseComponent {
  specifyConfig(value: string): FieldConfig {
    const selected = this.config.options.items.find(
      item => item.value === value
    );

    return selected &&
      selected.options &&
      selected.options.specify &&
      selected.options.specify.type
      ? selected.options.specify
      : undefined;
  }

  change() {
    // clear any spec values unrelated to current selection
    const value = this.group.get(this.config.name).value;
    this.config.options.items
      .filter(item => item.value !== value)
      .forEach(item => {
        const spec = this.specifyConfig(item.value);
        if (spec && this.group.get(spec.name)) {
          this.group.get(spec.name).reset();
          this.group.get(spec.name).disable();
        }
      });
  }
}
