import { Component } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-slide-toggle',
  templateUrl: './form-slide-toggle.component.html',
  styleUrls: ['./form-slide-toggle.component.css']
})
export class FormSlideToggleComponent extends DynamicBaseComponent {}
