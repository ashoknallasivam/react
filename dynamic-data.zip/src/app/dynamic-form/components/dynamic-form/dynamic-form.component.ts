import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output
} from '@angular/core';
import {
    AbstractControl,
    FormArray,
    FormControl,
    FormGroup
} from '@angular/forms';

import { ElementConfig } from '../../../element-config/element-config';
import { ElementType } from '../../../element-config/element-type';
import { DynamicFormBuilder } from '../../dynamic-form-builder';
import { ActionButtons } from '../../enumerations/action-buttons';
import { FieldConfig } from '../../interfaces/field-config';

import * as uuidv4_ from 'uuid/v4';
// workaround - assign import to a variable to avoid
// rollup.js error "Cannot call a namespace ('uuidv4')"
const uuid: any = uuidv4_;

@Component({
    selector: 'dynamic-form',
    templateUrl: './dynamic-form.component.html',
    styleUrls: ['./dynamic-form.component.css']
})
export class DynamicFormComponent implements OnChanges, OnInit {
    @Input()
    layout?: FieldConfig[] = [];
    @Input()
    entity?: any;

    @Output()
    valueChanges: EventEmitter<any> = new EventEmitter<any>();

    @Output()
    cancel: EventEmitter<any> = new EventEmitter<any>();
    @Output()
    remove: EventEmitter<any> = new EventEmitter<any>();
    @Output()
    submit: EventEmitter<any> = new EventEmitter<any>();

    id: string;
    form: FormGroup;
    dynFormBuilder: DynamicFormBuilder;
    submitted: boolean;

    get changes() {
        return this.form.valueChanges;
    }

    get valid() {
        return this.form.valid;
    }

    get errors() {
        return this.getErrors(this.form);
    }

    get value() {
        // getRawValue will include disabled controls. value will not.
        return this.form.getRawValue();
        // this.form.value;
    }

    constructor(private elRef: ElementRef) {
        this.id = `dd-id-${uuid()}`;
        this.dynFormBuilder = new DynamicFormBuilder();
        this.submitted = false;
    }

    ngOnInit() {
        this.form = this.dynFormBuilder.createForm();
        this.reconcileLayout();
        this.reconcileForm();

        this.form.valueChanges.subscribe(val => {
            this.valueChanges.emit(val);
        });
    }

    ngOnChanges() {
        this.reconcileLayout();
        this.reconcileForm();
    }

    reconcileForm() {
        if (this.dynFormBuilder && this.form) {
            this.dynFormBuilder.reconcileForm(
                this.form,
                this.layout,
                this.entity
            );
        }
    }

    reconcileLayout() {
        if (!this.layout) {
            const actionToolbar = ElementConfig.get(ElementType.ActionToolbar)
                .entity;
            if (this.entity && this.entity.fields) {
                // we know we're editing so let's include the delete button
                actionToolbar.options.buttons.allowDelete = true;
                this.layout = ElementConfig.parseEntity(this.entity.fields);
            } else {
                // this is a new layout; no delete needed
                actionToolbar.options.buttons.allowDelete = false;
                this.layout = [];
                this.layout.push(
                    ElementConfig.get(ElementType.LayoutEditor).layout
                );
            }
            this.layout.push(actionToolbar);
        }
    }

    validateFormControls(control: AbstractControl) {
        if (control instanceof FormControl) {
            control.markAsTouched({ onlySelf: true });
            return;
        } else if (control instanceof FormGroup) {
            // controls is json object, so get keys and loop to get form controls
            Object.keys(control.controls).forEach(key => {
                const c = control.get(key);
                c.markAsTouched({ onlySelf: true });
                this.validateFormControls(c);
            });
        } else if (control instanceof FormArray) {
            // controls is array, so use it
            control.controls.forEach(c => {
                c.markAsTouched({ onlySelf: true });
                this.validateFormControls(c);
            });
        }
    }

    validate() {
        this.validateFormControls(this.form);
    }

    handleSubmit(event: Event) {
        event.preventDefault();
        event.stopPropagation();
        this.submitted = true;
        const btn = this.elRef.nativeElement.querySelector(
            'button.cdk-focused.cdk-mouse-focused'
        );
        if (btn) {
            const action = btn.getAttribute('data-action');
            switch (action) {
                case ActionButtons.Delete:
                    this.remove.emit(this.value);
                    break;
                case ActionButtons.Cancel:
                    this.cancel.emit(this.value);
                    break;
                case ActionButtons.Submit:
                    this.validateFormControls(this.form);
                    this.submit.emit(this.value);
                    break;
                default:
                    console.log('Unknown action');
                    break;
            }
        }
    }

    setDisabled(name: string, disable: boolean) {
        // if already added to controls, change there
        if (this.form.controls[name]) {
            const method = disable ? 'disable' : 'enable';
            this.form.controls[name][method]();
            return;
        }
        // otherwise, change config so it is built with corret disable
        this.layout = this.layout.map(item => {
            if (item.name === name) {
                if (!item.options) {
                    item.options = {};
                }
                item.options.disabled = disable;
            }
            return item;
        });
    }

    getValue(name: string): any {
        const value = this.entity ? this.entity[name] : this.entity;

        if (!value) {
            return value;
        }

        const config = this.layout.find(field => field.name === name);
        // type conversion
        switch (config ? config.type : '') {
            case 'date':
                return new Date(value);
            default:
                return value;
        }
    }

    getControlErrors(key: string, control: any) {
        if (control instanceof FormControl) {
            return {
                field: key,
                errors: control.errors
            };
        }

        let errs = control.errors;
        let childErrs = null;

        if (control instanceof FormGroup) {
            childErrs = this.getErrors(control as FormGroup);
        } else if (control instanceof FormArray) {
            childErrs = (control as FormArray).controls
                .map((c, i) => {
                    return this.getControlErrors(key + '[' + i + ']', c);
                })
                .filter(x => x.errors);
        }

        if (childErrs && childErrs.length > 0) {
            if (!errs) {
                errs = {};
            }
            errs['children'] = childErrs;
        }
        return {
            field: key,
            errors: errs
        };
    }

    getErrors(group: FormGroup) {
        if (!group.controls) {
            return {};
        }

        return Object.keys(group.controls)
            .map(key => {
                return this.getControlErrors(key, group.controls[key]);
            })
            .filter(x => x.errors);
    }

    getControlsForGroup(group: FormGroup) {
        if (!group || !group.controls) {
            return [];
        }
        const keys = Object.keys(group.controls);
        if (!keys || keys.length === 0) {
            return [];
        }
        return keys.map(key => group.controls[key]);
    }
}
