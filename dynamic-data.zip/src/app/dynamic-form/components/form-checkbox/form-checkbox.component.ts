import { Component } from '@angular/core';

import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-checkbox',
  templateUrl: './form-checkbox.component.html',
  styleUrls: ['./form-checkbox.component.css']
})
export class FormCheckboxComponent extends DynamicBaseComponent {
  getConfig() {
    return this.config;
  }

  specifyConfig(): FieldConfig {
    return this.config.options &&
      this.config.options.specify &&
      this.config.options.specify.type &&
      this.config.options.specify.name
      ? this.config.options.specify
      : undefined;
  }

  change() {
    const spec = this.specifyConfig();

    // if value cleared & spec exists, then clear spec value too
    if (!this.group.get(this.config.name).value) {
      if (spec && this.group.get(spec.name)) {
        this.group.get(spec.name).reset();
        this.group.get(spec.name).disable();
      }
    } else {
      if (spec && this.group.get(spec.name)) {
        this.group.get(spec.name).enable();
      }
    }
  }
}
