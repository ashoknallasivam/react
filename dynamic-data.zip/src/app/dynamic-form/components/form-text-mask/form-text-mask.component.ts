import { Component, OnInit } from '@angular/core';

import {
  ElementType,
  PhoneConfig,
  SsnConfig,
  TimeConfig,
  ZipConfig
} from '../../../element-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-text-mask',
  templateUrl: './form-text-mask.component.html',
  styleUrls: ['./form-text-mask.component.css']
})
export class FormTextMaskComponent extends DynamicBaseComponent {
  hint(): string {
    return this.config.type === ElementType.Phone
      ? PhoneConfig.hint
      : this.config.type === ElementType.Ssn
        ? SsnConfig.hint
        : this.config.type === ElementType.Time
          ? TimeConfig.hint
          : this.config.type === ElementType.Zip
            ? ZipConfig.hint
            : this.config.options.hint;
  }
  inputMask(): string {
    return this.config.type === ElementType.Phone
      ? PhoneConfig.inputMask
      : this.config.type === ElementType.Ssn
        ? SsnConfig.inputMask
        : this.config.type === ElementType.Time
          ? TimeConfig.inputMask
          : this.config.type === ElementType.Zip
            ? ZipConfig.inputMask
            : this.config.options.inputMask;
  }
  pattern(): string {
    return this.config.type === ElementType.Phone
      ? PhoneConfig.pattern
      : this.config.type === ElementType.Ssn
        ? SsnConfig.pattern
        : this.config.type === ElementType.Time
          ? TimeConfig.pattern
          : this.config.type === ElementType.Zip
            ? ZipConfig.pattern
            : this.config.options.validation.pattern;
  }
  patternValidationMessage(): string {
    return this.config.type === ElementType.Phone
      ? PhoneConfig.patternValMsg
      : this.config.type === ElementType.Ssn
        ? SsnConfig.patternValMsg
        : this.config.type === ElementType.Time
          ? TimeConfig.patternValMsg
          : this.config.type === ElementType.Zip
            ? ZipConfig.patternValMsg
            : this.config.options.validation.patternValMsg ||
              `${this.config.label} should follow the pattern of ${
                this.config.options.validation.pattern
              }.`;
  }
  dropSpecialCharacters() {
    return this.config.type === ElementType.Time ? false : true;
  }
}
