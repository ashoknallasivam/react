import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { FormTextMaskComponent } from './form-text-mask.component';

describe('FormTextMaskComponent', () => {
  let component: FormTextMaskComponent;
  let fixture: ComponentFixture<FormTextMaskComponent>;
  let input: HTMLElement;
  let label: HTMLElement;
  let hint: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FormTextMaskComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormTextMaskComponent);
    component = fixture.componentInstance;

    // query for elements
    input = fixture.debugElement.query(By.css('input[type="text"]'))
      .nativeElement;
    label = fixture.debugElement.query(By.css('label')).nativeElement;
    hint = fixture.debugElement.query(By.css('md-hint')).nativeElement;

    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should render', () => {
    component.config = {
      name: 'name',
      type: 'text',
      label: 'Full name',
      options: {
        hint: 'Enter your full name.',
        validation: {
          required: true,
          minLength: 3,
          maxLength: 100
        }
      }
    };

    fixture.detectChanges();
    expect(input.textContent).toContain('');
    expect(label.textContent).toContain(component.config.label);
    expect(hint.textContent).toContain(component.config.options.hint);
  });
});
