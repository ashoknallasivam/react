import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { FieldConfig } from '../../interfaces/field-config';
import { ItemConfig } from '../../interfaces/item-config';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-text',
  templateUrl: './form-text.component.html',
  styleUrls: ['./form-text.component.css']
})
export class FormTextComponent extends DynamicBaseComponent implements OnInit {
  filteredItems: Observable<any[]>;
  items: string[];

  ngOnInit() {
    if (
      this.config &&
      this.config.options &&
      !!this.config.options.autocomplete &&
      this.group &&
      this.group.get(this.config.name)
    ) {
      this.items = this.getItems(this.config.options.items);
      this.filteredItems = this.group
        .get(this.config.name)
        .valueChanges.pipe(startWith(null))
        .pipe(map(text => this.filterItems(text)));
    }
    super.ngOnInit();
  }

  getItems(config: ItemConfig[]): string[] {
    return config ? config.map(item => item.label) : [];
  }

  filterItems(text: string) {
    return !text
      ? this.items.slice()
      : this.items.filter(
          i => i.toLowerCase().indexOf(text.toLowerCase()) === 0
        );
  }
}
