import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';

@Component({
  selector: 'dynamic-form-heading',
  templateUrl: './form-heading.component.html',
  styleUrls: ['./form-heading.component.css']
})
export class FormHeadingComponent implements Field {
  config: FieldConfig;
  group: FormGroup;
}
