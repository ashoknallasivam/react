import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';

@Component({
  selector: 'dynamic-form-static-panel',
  templateUrl: './form-static-panel.component.html',
  styleUrls: ['./form-static-panel.component.css']
})
export class FormStaticPanelComponent implements Field {
  config: FieldConfig;
  group: FormGroup;
}
