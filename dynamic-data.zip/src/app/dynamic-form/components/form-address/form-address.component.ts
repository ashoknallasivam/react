/// <reference types="@types/googlemaps" />

import { Component, OnInit } from '@angular/core';

import { MapsAPILoader } from '@agm/core';
import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-address',
  templateUrl: './form-address.component.html',
  styleUrls: ['./form-address.component.css']
})
export class FormAddressComponent extends DynamicBaseComponent
  implements OnInit {
  constructor(private mapsAPILoader: MapsAPILoader) {
    super();
  }

  ngOnInit() {
    // load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      const input: HTMLInputElement = document.getElementById(
        this.id
      ) as HTMLInputElement;
      const autocomplete = new google.maps.places.Autocomplete(input, {
        types: ['address']
      });
      this.geolocate(autocomplete);

      // store control in variable before scope change
      const control = this.group.get(this.config.name);
      autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        control.patchValue(place.formatted_address);
      });
    });

    super.ngOnInit();
  }

  geolocate(autocomplete) {
    // Bias the autocomplete object to the user's geographical location,
    // as supplied by the browser's 'navigator.geolocation' object.
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const geolocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        const circle = new google.maps.Circle({
          center: geolocation,
          radius: position.coords.accuracy
        });
        autocomplete.setBounds(circle.getBounds());
      });
    }
  }
}
