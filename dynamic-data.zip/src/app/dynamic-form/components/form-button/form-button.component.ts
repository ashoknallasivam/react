import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';

@Component({
  selector: 'dynamic-form-button',
  templateUrl: './form-button.component.html',
  styleUrls: ['./form-button.component.css']
})
export class FormButtonComponent implements Field {
  config: FieldConfig;
  group: FormGroup;

  setValidators() {
    // do nothing
  }
}
