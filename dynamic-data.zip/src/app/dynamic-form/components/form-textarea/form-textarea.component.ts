import { Component } from '@angular/core';

import { DynamicBaseComponent } from '../dynamic-base-component';

@Component({
  selector: 'dynamic-form-textarea',
  templateUrl: './form-textarea.component.html',
  styleUrls: ['./form-textarea.component.css']
})
export class FormTextareaComponent extends DynamicBaseComponent {}
