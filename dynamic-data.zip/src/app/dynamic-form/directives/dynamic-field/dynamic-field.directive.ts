import {
  ComponentFactoryResolver,
  ComponentRef,
  Directive,
  Input,
  OnChanges,
  OnInit,
  Type,
  ViewContainerRef
} from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';

import { ActionToolbarComponent } from '../../components/action-toolbar/action-toolbar.component';
import { FormAddressComponent } from '../../components/form-address/form-address.component';
import { FormArrayComponent } from '../../components/form-array/form-array.component';
import { FormButtonComponent } from '../../components/form-button/form-button.component';
import { FormCheckboxGroupComponent } from '../../components/form-checkbox-group/form-checkbox-group.component';
import { FormCheckboxComponent } from '../../components/form-checkbox/form-checkbox.component';
import { FormDateComponent } from '../../components/form-date/form-date.component';
import { FormEmailComponent } from '../../components/form-email/form-email.component';
import { FormExpansionPanelComponent } from '../../components/form-expansion-panel/form-expansion-panel.component';
import { FormFieldSetComponent } from '../../components/form-fieldset/form-fieldset.component';
import { FormHeadingComponent } from '../../components/form-heading/form-heading.component';
import { FormNumberComponent } from '../../components/form-number/form-number.component';
import { FormPasswordComponent } from '../../components/form-password/form-password.component';
import { FormRadioComponent } from '../../components/form-radio/form-radio.component';
import { FormSelectComponent } from '../../components/form-select/form-select.component';
import { FormSlideToggleComponent } from '../../components/form-slide-toggle/form-slide-toggle.component';
import { FormSliderComponent } from '../../components/form-slider/form-slider.component';
import { FormStatesComponent } from '../../components/form-states/form-states.component';
import { FormStaticPanelComponent } from '../../components/form-static-panel/form-static-panel.component';
import { FormStaticComponent } from '../../components/form-static/form-static.component';
import { FormTextMaskComponent } from '../../components/form-text-mask/form-text-mask.component';
import { FormTextComponent } from '../../components/form-text/form-text.component';
import { FormTextareaComponent } from '../../components/form-textarea/form-textarea.component';
import { FormTimeComponent } from '../../components/form-time/form-time.component';
import { LayoutEditorComponent } from '../../components/layout-editor/layout-editor.component';

const components: { [type: string]: Type<Field> } = {
  'action-toolbar': ActionToolbarComponent,
  address: FormAddressComponent,
  array: FormArrayComponent,
  button: FormButtonComponent,
  checkbox: FormCheckboxComponent,
  'checkbox-group': FormCheckboxGroupComponent,
  date: FormDateComponent,
  email: FormEmailComponent,
  fieldset: FormFieldSetComponent,
  heading: FormHeadingComponent,
  'layout-editor': LayoutEditorComponent,
  number: FormNumberComponent,
  panel: FormExpansionPanelComponent,
  password: FormPasswordComponent,
  phone: FormTextMaskComponent,
  radio: FormRadioComponent,
  select: FormSelectComponent,
  slider: FormSliderComponent,
  'slide-toggle': FormSlideToggleComponent,
  ssn: FormTextMaskComponent,
  states: FormStatesComponent,
  static: FormStaticComponent,
  'static-panel': FormStaticPanelComponent,
  text: FormTextComponent,
  textarea: FormTextareaComponent,
  'text-mask': FormTextMaskComponent,
  time: FormTimeComponent,
  zip: FormTextMaskComponent
};

@Directive({
  selector: '[dynamicField]',
  exportAs: 'dynamicForm'
})
export class DynamicFieldDirective implements Field, OnChanges, OnInit {
  @Input()
  config: FieldConfig;
  @Input()
  group: FormGroup;

  component: ComponentRef<Field>;

  constructor(
    private resolver: ComponentFactoryResolver,
    private container: ViewContainerRef
  ) {}

  ngOnChanges() {
    if (this.component) {
      this.component.instance.config = this.config;
      this.component.instance.group = this.group;
    }
  }

  ngOnInit() {
    if (!this.config) {
      throw new Error(`Configuration missing`);
    }
    if (!this.group) {
      throw new Error(`FormGroup missing`);
    }
    if (this.config.type && !components[this.config.type]) {
      const supportedTypes = Object.keys(components).join(', ');
      throw new Error(
        `Trying to use an unsupported type (${this.config.type}).
        Supported types: ${supportedTypes}`
      );
    }
    const component = this.resolver.resolveComponentFactory<Field>(
      components[this.config.type]
    );
    this.component = this.container.createComponent(component);
    this.component.instance.config = this.config;
    this.component.instance.group = this.group;
  }
}
