import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';

import { ElementType } from '../element-config/element-type';
import { FieldConfig } from './interfaces/field-config';
import { ItemConfig } from './interfaces/item-config';
import { RequiredMinimumValidator } from './validators/required-minimum';

export class DynamicFormBuilder {
  public fb: FormBuilder;

  constructor() {
    this.fb = new FormBuilder();
  }

  createForm() {
    return this.fb.group({});
  }

  reconcileForm(form: FormGroup, layout: FieldConfig[], entity: any) {
    this.reconcileGroup(form, layout, entity);
  }

  reconcileGroup(group: FormGroup, configs: FieldConfig[], entity: any) {
    const controlKeys = Object.keys(group.controls);
    const itemSpecs = this.getSpecify(configs);

    const configNames = configs
      .filter(config => this.isControl(config.type))
      .map(field => field.name)
      .concat(
        configs
          .filter(config => this.hasSpecify(config))
          .map(field => field.options.specify.name),
        itemSpecs.map(field => field.name)
      )
      // remove null values from configNames
      .filter(config => config);

    // if key is not found in configs, remove the control from the group
    controlKeys
      .filter(key => configNames.indexOf(key) === -1)
      .forEach(key => group.removeControl(key));

    // if config name not found in keys, add the control to the group
    configNames
      .filter(name => controlKeys.indexOf(name) === -1)
      .forEach(name => {
        let entityValue = entity ? entity[name] : entity;
        const config = configs.find(field => field.name === name);
        if (config) {
          if (config.options.defaultValue && entityValue === undefined) {
            entityValue = config.options.defaultValue;
          }
          group.addControl(
            config.name,
            this.createControl(config, entityValue)
          );
          if (this.hasSpecify(config)) {
            const specifyValue = entity
              ? entity[config.options.specify.name]
              : entity;
            group.addControl(
              config.options.specify.name,
              this.createControl(config.options.specify, specifyValue)
            );
          }
          if (config.options && config.options.items) {
            config.options.items.forEach(item => {
              if (this.hasSpecify(item) && item.options.specify.name) {
                const specifyValue = entity
                  ? entity[item.options.specify.name]
                  : entity;
                group.addControl(
                  item.options.specify.name,
                  this.createControl(item.options.specify, specifyValue)
                );
              }
            });
          }
        }
      });
  }

  createControl(config: FieldConfig, entity?: any): AbstractControl {
    if (this.isGroup(config.type)) {
      return this.createGroup(config, entity);
    }

    if (this.isEditorArray(config.type)) {
      return this.createEditorArray(config, entity);
    }

    if (this.isArray(config.type)) {
      const length =
        entity && Array.isArray(entity)
          ? entity.length
          : config.options && config.options.defaultEmpty === true
            ? 0
            : 1;
      return this.createArray(config, length, entity);
    }

    const disabled = config.options ? config.options.disabled : false;
    if (config.type === 'date' && entity) {
      entity = new Date(entity);
    }
    return this.fb.control({ disabled, value: entity });
  }

  createGroup(groupConfig: any, entity?: any): FormGroup {
    const validator = this.createGroupValidator(groupConfig);
    const group = this.fb.group({}, validator);

    // addControlsToGroup
    const configs: FieldConfig[] =
      groupConfig.options && groupConfig.options.fields
        ? groupConfig.options.fields
        : groupConfig;
    configs.filter(config => this.isControl(config.type)).forEach(config => {
      let entityValue = entity ? entity[config.name] : entity;
      if (config.options.defaultValue && entityValue === undefined) {
        entityValue = config.options.defaultValue;
      }
      group.addControl(config.name, this.createControl(config, entityValue));
      if (this.hasSpecify(config)) {
        const specifyValue = entity
          ? entity[config.options.specify.name]
          : entity;
        group.addControl(
          config.options.specify.name,
          this.createControl(config.options.specify, specifyValue)
        );
      }
      if (config.options && config.options.items) {
        config.options.items.forEach(item => {
          if (this.hasSpecify(item) && item.options.specify.name) {
            const specifyValue = entity
              ? entity[item.options.specify.name]
              : entity;
            group.addControl(
              item.options.specify.name,
              this.createControl(item.options.specify, specifyValue)
            );
          }
        });
      }
    });
    return group;
  }

  createArray(
    arrayConfig: FieldConfig,
    length: number,
    entity?: any
  ): FormArray {
    const validators = this.createArrayValidator(arrayConfig);
    const array = this.fb.array([], validators);

    for (let i = 0; i < length; i++) {
      // TODO: test array > group > array > group recursive
      const group = this.createGroup(
        arrayConfig,
        entity && entity.length >= i && entity[i] ? entity[i] : entity
      );
      array.push(group);
    }
    return array;
  }

  createEditorArray(arrayConfig: FieldConfig, entity?: any): FormArray {
    const validators = this.createArrayValidator(arrayConfig);
    const array = this.fb.array([], validators);

    for (let i = 0; i < arrayConfig.options.fields.length; i++) {
      const group = this.createGroup(arrayConfig.options.fields[i], entity[i]);
      array.push(group);
    }
    return array;
  }

  createGroupValidator(config?: any) {
    if (!config || !config.options || !config.options.validation) {
      return;
    }
    if (config.options.validation.requiredMin) {
      // must return function
      const val = new RequiredMinimumValidator(
        config.options.validation.requiredMin
      ).validate;
      return { validator: val };
    }
  }

  createArrayValidator(config?: any) {
    const arr = [];
    if (!config || !config.options || !config.options.validation) {
      return null;
    }
    if (config.options.validation.required) {
      arr.push(Validators.required);
    }
    if (config.options.validation.minLength) {
      arr.push(Validators.minLength(config.options.validation.minLength));
    }
    if (config.options.validation.maxLength) {
      arr.push(Validators.maxLength(config.options.validation.maxLength));
    }
    return Validators.compose(arr);
  }

  isGroup(type: string): boolean {
    return (
      type === ElementType.CheckboxGroup ||
      type === ElementType.Fieldset ||
      type === ElementType.Panel
    );
  }

  isArray(type: string): boolean {
    return type === ElementType.Array;
  }

  isEditorArray(type: string): boolean {
    return type === ElementType.LayoutEditor;
  }

  isControl(type: string): boolean {
    return !/*type === 'button' ||*/ (
      type === ElementType.Heading || type === ElementType.Static
    );
  }

  hasSpecify(config: FieldConfig | ItemConfig): boolean {
    return config.options && !!config.options.specify;
  }

  getSpecify(items: ItemConfig[]): FieldConfig[] {
    return items
      .filter(item => this.hasSpecify(item))
      .map(item => item.options.specify);
  }
}
