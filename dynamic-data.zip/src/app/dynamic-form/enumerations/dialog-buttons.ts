export enum DialogButtons {
  OK,
  OKCancel,
  NextCancel,
  SaveCancel,
  SubmitCancel,
  YesNo
}
