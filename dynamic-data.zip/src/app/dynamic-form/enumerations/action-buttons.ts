export enum ActionButtons {
  Cancel = 'cancel',
  Delete = 'delete',
  Submit = 'submit',
}
