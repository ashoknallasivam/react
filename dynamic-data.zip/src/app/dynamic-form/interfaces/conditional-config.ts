export interface ConditionalConfig {
  property: string;
  value: string;
}
