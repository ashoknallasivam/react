import { ConditionalConfig } from './conditional-config';

export interface ValidationConfig {
  required?: boolean;
  requiredIf?: ConditionalConfig;
  requiredMin?: number;
  pattern?: string;
  patternValMsg?: string;
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  minDate?: Date;
  maxDate?: Date;
}
