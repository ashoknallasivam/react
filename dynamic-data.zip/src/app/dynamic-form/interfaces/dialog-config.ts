import { DialogButtons } from '../enumerations/dialog-buttons';
import { FieldConfig } from './field-config';

export interface DialogConfig {
  heading?: string;
  size?: string; // sm, md, lg
  layout: FieldConfig[];
  entity?: {};
  dialogButtons: DialogButtons;
  preformattedJson?: boolean;
}
