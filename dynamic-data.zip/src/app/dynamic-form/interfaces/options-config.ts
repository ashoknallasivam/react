import { ActionButtonConfig } from './action-button-config';
import { ConditionalConfig } from './conditional-config';
import { FieldConfig } from './field-config';
import { ItemConfig } from './item-config';
import { ValidationConfig } from './validation-config';

export interface OptionsConfig {
  hint?: string;
  showIf?: ConditionalConfig;
  validation?: ValidationConfig;
  disabled?: boolean;
  inputMask?: string;
  states?: any;
  defaultValue?: any;
  defaultEmpty?: boolean;

  helpBlock?: string;
  icon?: string;
  tooltip?: string;

  specify?: FieldConfig;

  // action-toolbar
  buttons?: ActionButtonConfig;

  // array
  addText?: string;
  removeText?: string;

  // text
  autocomplete?: boolean;

  // address, phone
  allowMulti?: boolean;

  // select, checkbox group, radio group
  items?: ItemConfig[];

  // date
  startAt?: Date;

  // checkbox
  indeterminate?: boolean;
  align?: string;

  // radio & slider
  vertical?: boolean;

  // slider
  invert?: boolean;
  thumbLabel?: boolean;
  step?: number;
  tickInterval?: string;

  // heading
  level?: number;

  // containers like fieldset
  fields?: FieldConfig[];

  // slide-toggle
  color?: string;

  // chips
  removable?: boolean;
}
