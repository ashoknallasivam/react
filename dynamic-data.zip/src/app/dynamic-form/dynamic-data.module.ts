import { AgmCoreModule } from '@agm/core';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../core/core.module';
import { SharedModule } from '../shared/shared.module';

import { NgxTrumbowygModule } from 'ngx-trumbowyg';
import { ActionToolbarComponent } from './components/action-toolbar/action-toolbar.component';
import { DynamicFormComponent } from './components/dynamic-form/dynamic-form.component';
import { DynamicModalDialogComponent } from './components/dynamic-modal-dialog/dynamic-modal-dialog.component';
import { FormAddressComponent } from './components/form-address/form-address.component';
import { FormArrayComponent } from './components/form-array/form-array.component';
import { FormButtonComponent } from './components/form-button/form-button.component';
import { FormCheckboxGroupComponent } from './components/form-checkbox-group/form-checkbox-group.component';
import { FormCheckboxComponent } from './components/form-checkbox/form-checkbox.component';
import { FormDateComponent } from './components/form-date/form-date.component';
import { FormEmailComponent } from './components/form-email/form-email.component';
import { FormExpansionPanelComponent } from './components/form-expansion-panel/form-expansion-panel.component';
import { FormFieldSetComponent } from './components/form-fieldset/form-fieldset.component';
import { FormHeadingComponent } from './components/form-heading/form-heading.component';
import { FormNumberComponent } from './components/form-number/form-number.component';
import { FormPasswordComponent } from './components/form-password/form-password.component';
import { FormRadioComponent } from './components/form-radio/form-radio.component';
import { FormSelectComponent } from './components/form-select/form-select.component';
import { FormSlideToggleComponent } from './components/form-slide-toggle/form-slide-toggle.component';
import { FormSliderComponent } from './components/form-slider/form-slider.component';
import { FormStatesComponent } from './components/form-states/form-states.component';
import { FormStaticPanelComponent } from './components/form-static-panel/form-static-panel.component';
import { FormStaticComponent } from './components/form-static/form-static.component';
import { FormTextMaskComponent } from './components/form-text-mask/form-text-mask.component';
import { FormTextComponent } from './components/form-text/form-text.component';
import { FormTextareaComponent } from './components/form-textarea/form-textarea.component';
import { FormTimeComponent } from './components/form-time/form-time.component';
import { LayoutEditorComponent } from './components/layout-editor/layout-editor.component';
import { DynamicFieldDirective } from './directives/dynamic-field/dynamic-field.directive';

@NgModule({
  imports: [
    CommonModule,
    CoreModule,
    SharedModule,
    ReactiveFormsModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAdOa90pqGf2iukXoy43TBYQcfUE-nYqjQ',
      libraries: ['places']
    }),
    NgxTrumbowygModule.withConfig({
      svgPath: '/assets/trumbowyg-icons.svg',
      removeformatPasted: true
    })
  ],
  declarations: [
    // directives
    DynamicFieldDirective,

    // components
    ActionToolbarComponent,
    DynamicFormComponent,
    DynamicModalDialogComponent,
    FormAddressComponent,
    FormArrayComponent,
    FormButtonComponent,
    FormCheckboxComponent,
    FormCheckboxGroupComponent,
    FormDateComponent,
    FormEmailComponent,
    FormFieldSetComponent,
    FormHeadingComponent,
    FormNumberComponent,
    FormPasswordComponent,
    FormRadioComponent,
    FormSelectComponent,
    FormSliderComponent,
    FormSlideToggleComponent,
    FormStatesComponent,
    FormStaticComponent,
    FormStaticPanelComponent,
    FormTextComponent,
    FormTextareaComponent,
    FormTextMaskComponent,
    FormTimeComponent,
    FormExpansionPanelComponent,
    LayoutEditorComponent
  ],
  exports: [DynamicFormComponent, LayoutEditorComponent],
  entryComponents: [
    ActionToolbarComponent,
    DynamicModalDialogComponent,
    FormAddressComponent,
    FormArrayComponent,
    FormButtonComponent,
    FormCheckboxComponent,
    FormCheckboxGroupComponent,
    FormDateComponent,
    FormEmailComponent,
    FormFieldSetComponent,
    FormHeadingComponent,
    FormNumberComponent,
    FormPasswordComponent,
    FormRadioComponent,
    FormSelectComponent,
    FormSliderComponent,
    FormSlideToggleComponent,
    FormStatesComponent,
    FormStaticComponent,
    FormStaticPanelComponent,
    FormTextComponent,
    FormTextareaComponent,
    FormTextMaskComponent,
    FormTimeComponent,
    FormExpansionPanelComponent,
    LayoutEditorComponent
  ],
  providers: []
})
export class DynamicDataModule {}
