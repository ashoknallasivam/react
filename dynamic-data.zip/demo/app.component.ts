import { Component, OnInit, ViewChild } from '@angular/core';

import { DynamicFormComponent } from '../src/app/dynamic-form/components/dynamic-form/dynamic-form.component';
import { FieldConfig } from '../src/app/dynamic-form/interfaces/field-config';

// reference published library
// import {FieldConfig} from '../lib/dynamic-form/interfaces/field-config';
// import {DynamicFormComponent} from '../lib/dynamic-form/components/dynamic-form/dynamic-form.component';

import { LayoutService } from './layout.service';

@Component({
  selector: 'dynamic-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  // for json api
  @ViewChild('form')
  formDemoType: DynamicFormComponent;

  @ViewChild('form')
  form: DynamicFormComponent;

  jsonSelect: FieldConfig[] = [];
  selectedJson: {};

  layout: FieldConfig[] = [];
  entity: {};

  formValue: any;

  constructor(private layoutService: LayoutService) {}

  ngOnInit() {
    // for json api
    this.layoutService.get('./api/demo-select.json').subscribe(data => {
      // for json api demo
      this.jsonSelect = data['layout'];
    });
  }

  onChange(val: any) {
    if (val && val.hasOwnProperty('demoType') && val.demoType) {
      this.layoutService.get(val.demoType).subscribe(data => {
        // for json api demo
        this.layout = data['layout'];
        this.entity = data['entity'];
      });
    }
  }

  onSubmit(value: { [name: string]: any }) {
    // handle submit event
    this.formValue = value;
    console.log('handle submit');
    console.log(this.formValue);
  }

  onDelete() {
    // handle delete event
    console.log('handle delete');
  }

  onCancel() {
    // handle cancel event
    console.log('handle cancel');
  }
}
