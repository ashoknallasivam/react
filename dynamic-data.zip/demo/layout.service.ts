import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable()
export class LayoutService {
    constructor(private http: HttpClient) {}

    get(url: string): Observable<any> {
        return (
            this.http
                .get(url)
                // .delay(2000)
                .pipe(data => {
                    return data;
                })
                .pipe(
                    catchError(error => {
                        throw error;
                    })
                )
        );
    }
}
