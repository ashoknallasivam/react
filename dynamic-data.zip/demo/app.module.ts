import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DynamicDataModule } from '../src/app/dynamic-form/dynamic-data.module';
import { AppComponent } from './app.component';
import { LayoutService } from './layout.service';

// published library
// import {DynamicDataModule} from '../lib/dynamic-form/dynamic-data.module';
// import {LayoutService} from '../lib/dynamic-form/services/layout-service/layout.service';

@NgModule({
  imports: [BrowserModule, DynamicDataModule],
  declarations: [AppComponent],
  providers: [LayoutService],
  bootstrap: [AppComponent]
})
export class AppModule {}
