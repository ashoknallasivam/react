# Dynamic Data

![Mathematica Policy Research](https://mathematica-mpr.com/-/media/internet/logo.png)

**Dynamic Data** is an Angular module which allows you to create data-driven Web sites that require minimum code. Dynamic data combines [Angular Reactive Forms](https://angular.io/guide/reactive-forms) and JSON-defined layouts to dynamically generate input forms.

## Current Version

6.0.0

## Dependencies

| Dependency| Repository | Comments
|---|--- | ---
| Angular | https://github.com/angular/angular | |
| Angular Google Maps | https://github.com/SebastianM/angular-google-maps | Required for Google Maps API Integration
| jQuery | https://github.com/jquery/jquery | Required for Trumbowyg
| Material | https://github.com/angular/material2 | Material design components for Angular
| ngx-mask | https://github.com/JsDaddy/ngx-mask | An Angular text input masking directive
| Trumbowyg |https://github.com/alex-d/trumbowyg | A lightweight WYSIWYG Editor.
| ngx-trumbowyg | https://github.com/wermerb/ngx-trumbowyg | An Angular wrapper for Trumbowyg
| uuid | https://github.com/kelektiv/node-uuid | Simple, fast generation of RFC4122 UUIDS.

### Supported Material Components

Dynamic Data uses [Angular Material](https://material.angular.io/) components. The following Material components are currently supported:
- Autocomplete
- Checkbox
- Datepicker
- Expansion Panel
- Radio button
- Select
- Slide toggle
- Slider
- Text
- Textarea with integrated [Trumbowyg](https://https://alex-d.github.io/Trumbowyg/) WYSIWYG

***NOTE: It is up to the developer to sanitize HTML entered within their web application.***

### Additional Available Components

- Action toolbar
- Address
- Array
- Email
- Fieldset
- Heading
- Number
- Phone
- SSN
- Static
- Static Expansion Panel
- Text-mask (integrated input mask)
- Time
- Zip

#### Upcoming Components

- Cards
- Chips
- Lists
- Stepper
- Tabs

## Getting Started

Use Dynamic Data in your Angular project by following these steps or simply clone or fork the [Angular Dynamic Data Starter Template](https://github.com/mathematicaProducts/angular-dd-starter-template) project.

1. Start a new Angular project. It is recommended to generate a new project using [Angular CLI](https://github.com/angular/angular-cli).

2. Install Dynamic Data in your angular project:
    ```
    npm install --save git+https://git-codecommit.us-east-1.amazonaws.com/v1/repos/dynamic-data
    ```

3. Install peer dependencies:

    - Angular (if you did not use the Angular CLI)
    ```
    npm install --save @angular/core @angular/common @angular/forms
    ```
    - Material
    ```
    npm install --save @angular/material
    ```

4. Since Dynamic Data uses Material components, you must import the Material stylesheet. Add the following to your `styles.css`.
    ```
    @import '../node_modules/@angular/material/prebuilt-themes/indigo-pink.css';
    ```

5. In `index.html`, add a reference to Google's [Material icons](https://material.io/icons/):
    ```
      <!-- Required for material icons-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    ```

    Alternatively, you may reference downloaded Material icons.

6. Modify `angular.json` to include styles and scripts to work with Trumbowyg WYSIWYG editor:
    ```
        "styles": [
          "styles.css",
          "../node_modules/trumbowyg/dist/ui/trumbowyg.min.css"
        ],
        "scripts": [
          "../node_modules/jquery/dist/jquery.min.js",
          "../node_modules/trumbowyg/dist/trumbowyg.min.js"
        ],
    ```

    Alternatively, you may import the Trumbowyg styles directly into your `styles.css`:

    ```
    @import '../node_modules/trumbowyg/dist/ui/trumbowyg.min.css';
    ```

7. Copy the Trumbowyg icons to the Angular project's `assets` folder:

    Unix example:
    ```
    cp node_modules/trumbowyg/dist/ui/icons.svg src/assets/trumbowyg-icons.svg
    ```

    Windows example:
    ```
    xcopy /I /E node_modules/trumbowyg/dist/ui/icons.svg src/assets/trumbowyg-icons.svg
    ```

8. Import Dynamic Data into your `app.module.ts`:

    ```
    import { DynamicDataModule } from 'dynamic-data';

    @NgModule({
      declarations: [
        AppComponent
      ],
      imports: [
        BrowserModule,
        DynamicDataModule   // required for dynamic data
      ],
      providers: [],
      bootstrap: [AppComponent]
    })
    export class AppModule { }
    ```

9. Add a reference to a DynamicFormComponent into your `app.component.ts`:

    ```
    import {DynamicFormComponent} from 'dynamic-data';

    @Component({
      selector: 'app-root',
      templateUrl: './app.component.html',
      styleUrls: ['./app.component.css']
    })
    export class AppComponent implements OnInit {
      @ViewChild('form')

      //====== Each dynamic page requires the following properties ======
      form: DynamicFormComponent;
      layout: any[] = [];
      entity: {};
      //=========================================================

      formValue: any;

      ngOnInit() {
        // typically the layout would be provided by an api since it would be saved
        this.layout = [...]
      }

      ... <!--- code removed for brevity-->
    }
    ```


10. Add the `dynamic-form` selector into your `app.component.html`:

    ```
    <dynamic-form
      #form
      [layout]="layout"
      [entity]="entity">
    </dynamic-form>
    ```

A `dynamic-form` selector may be used on any dynamic page passing in a JSON-defined layout.

## Demo Application

Run the demo application using the Angular CLI.
```
ng serve -o
```

## Dynamic Data - Layout Editor

The `layout-editor` allows you to visually construct and generate a JSON-defined layout with ease.

A `layout-editor` may be integrated into your web application by using the same `dynamic-form` selector. Pass a null value for the layout and an empty JSON object for the entity value from your page or component.

```
  ngOnInit() {
    // set up your component to use the layout editor
    this.layout = null;
    this.entity = {};
  }
```

Alternatively, you can run the demo application and select the blank page demo to use the `layout-editor`.

Using the `layout-editor`, click the add element icon (`+`) to add a new element to your layout. You will be prompted to select the element to add the layout.

Repeat this until you have constructed the desired form. Click the view source icon (`< >`) to view the JSON-defined layout. This generated layout may be used within your web application.

***NOTE: It is up to the developer to decide how to handle saving the JSON-defined layout within their web application.***

## Dynamic Data - Action Toolbar

The `action-toolbar` component/element should be added to any dynamic page containing form inputs. The `action-toolbar` is a type of element which can be added using the `layout-editor`.

The purpose of the `action-toolbar` is to allow the developer to handle events emitted by the `dynamic-form` selector. Review the **Dynamic Form Events** section for more information.

***NOTE: It is up to the developer to decide how to handle authorization of the JSON-defined layout within their web application.***

An example of authorization is if a ***Delete*** button is allowed on the form but not all users may have access to the delete functionality.

### Dynamic Form Events

The available events are dependent on the buttons configured within the `action-toolbar` component.

Event | Description
---| ---
cancel | Event emitted when the ***Cancel*** button is clicked within the `action-toolbar`.
remove | Event emitted when the ***Delete*** button is clicked within the `action-toolbar`.
submit | Event emitted when the ***Submit*** button is clicked within the `action-toolbar`.

The events must be handled within the component containing the `dynamic-form` selector (ex. `app.component.html`).

```
<dynamic-form
  #form
  [layout]="layout"
  [entity]="entity"
  (cancel)="onCancel($event)"
  (remove)="onDelete($event)"
  (submit)="onSubmit($event)">
</dynamic-form>
```

```
export class AppComponent implements OnInit {
  ... <!--- code removed for brevity-->

  onCancel() {
    // handle cancel event
    console.log('handle cancel');
  }

  onDelete() {
    // handle delete event
    console.log('handle delete');
  }

  onSubmit(value: { [name: string]: any }) {
    / // handle submit event
    console.log('handle submit');
    console.log('Submitted: ' + JSON.stringify(value));
  }
}
```

***NOTE: It is up to the developer to decide how to handle the events emitted within their web application.***

The developer only has to handle events that they need to handle on the `dynamic-form`. The events emitted will be dependent on the JSON-defined layout.
