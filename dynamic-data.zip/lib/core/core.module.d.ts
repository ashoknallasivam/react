export declare class CoreModule {
}
