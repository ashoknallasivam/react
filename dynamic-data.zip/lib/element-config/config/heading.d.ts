export declare class HeadingConfig {
    layout: any;
    entity: any;
}
