export declare class CheckboxConfig {
    layout: any;
    entity: any;
}
