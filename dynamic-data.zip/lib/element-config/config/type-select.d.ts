export declare class TypeSelectConfig {
    layout: any;
}
