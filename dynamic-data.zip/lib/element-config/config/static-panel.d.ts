export declare class StaticPanelConfig {
    layout: any;
    entity: any;
}
