export declare class SliderConfig {
    layout: any;
    entity: any;
}
