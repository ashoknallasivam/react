export declare class SlideToggleConfig {
    layout: any;
    entity: any;
}
