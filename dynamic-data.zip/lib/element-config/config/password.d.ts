export declare class PasswordConfig {
    layout: any;
    entity: any;
}
