export declare class ButtonConfig {
    layout: any;
    entity: any;
}
