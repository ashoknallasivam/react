export declare class EmailConfig {
    static pattern: any;
    layout: any;
    entity: any;
}
