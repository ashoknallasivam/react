export declare class CheckboxGroupConfig {
    layout: any;
    entity: any;
}
