export declare class AddressConfig {
    layout: any;
    entity: any;
}
