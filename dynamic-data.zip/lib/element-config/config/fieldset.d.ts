export declare class FieldsetConfig {
    layout: any;
    entity: any;
}
