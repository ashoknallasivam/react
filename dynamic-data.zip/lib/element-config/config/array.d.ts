export declare class ArrayConfig {
    layout: any;
    entity: any;
}
