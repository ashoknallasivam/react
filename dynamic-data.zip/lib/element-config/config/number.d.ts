export declare class NumberConfig {
    layout: any;
    entity: any;
}
