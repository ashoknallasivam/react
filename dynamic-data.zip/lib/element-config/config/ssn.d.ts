export declare class SsnConfig {
    static hint: string;
    static inputMask: string;
    static pattern: string;
    static patternValMsg: string;
    layout: any;
    entity: any;
    constructor();
}
