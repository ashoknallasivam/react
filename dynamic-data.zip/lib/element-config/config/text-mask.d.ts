export declare class TextMaskConfig {
    layout: any;
    entity: any;
}
