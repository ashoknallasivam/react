export declare class StaticConfig {
    layout: any;
    entity: any;
}
