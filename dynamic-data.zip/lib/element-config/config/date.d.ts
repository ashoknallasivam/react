export declare class DateConfig {
    layout: any;
    entity: any;
}
