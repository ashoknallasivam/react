export declare class TextConfig {
    layout: any;
    entity: any;
}
