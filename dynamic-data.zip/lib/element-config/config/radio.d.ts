export declare class RadioConfig {
    layout: any;
    entity: any;
}
