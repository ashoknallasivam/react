export declare class ActionToolbarConfig {
    layout: any;
    entity: any;
}
