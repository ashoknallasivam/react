export declare class SelectConfig {
    layout: any;
    entity: any;
}
