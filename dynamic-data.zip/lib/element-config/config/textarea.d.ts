export declare class TextareaConfig {
    layout: any;
    entity: any;
}
