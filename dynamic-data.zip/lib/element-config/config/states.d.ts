export declare class StatesConfig {
    static states: any[];
    layout: any;
    entity: any;
}
