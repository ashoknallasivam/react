export declare class LayoutEditorConfig {
    layout: any;
}
