export declare class PanelConfig {
    layout: any;
    entity: any;
}
