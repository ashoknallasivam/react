export declare class ElementConfig {
    private static includeLayoutEditor;
    static get(elementType: string, includeEditor?: boolean): any;
    static getTypeSelection(): any;
    static hasNestedProperties(entity: any): boolean;
    static parseEntity(entity: any, push?: boolean): any;
}
