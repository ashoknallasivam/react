export declare enum DialogButtons {
    OK = 0,
    OKCancel = 1,
    NextCancel = 2,
    SaveCancel = 3,
    SubmitCancel = 4,
    YesNo = 5
}
