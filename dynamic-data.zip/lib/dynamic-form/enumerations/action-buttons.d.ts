export declare enum ActionButtons {
    Cancel = "cancel",
    Delete = "delete",
    Submit = "submit"
}
