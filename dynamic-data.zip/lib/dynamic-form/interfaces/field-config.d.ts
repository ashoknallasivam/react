import { OptionsConfig } from './options-config';
export interface FieldConfig {
    type: string;
    name?: string;
    label?: string;
    options?: OptionsConfig;
}
