import { DialogButtons } from '../enumerations/dialog-buttons';
import { FieldConfig } from './field-config';
export interface DialogConfig {
    heading?: string;
    size?: string;
    layout: FieldConfig[];
    entity?: {};
    dialogButtons: DialogButtons;
    preformattedJson?: boolean;
}
