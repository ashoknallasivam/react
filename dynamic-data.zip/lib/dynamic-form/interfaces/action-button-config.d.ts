export interface ActionButtonConfig {
    allowDelete: boolean;
    deleteButtonText: string;
    allowCancel: boolean;
    cancelButtonText: string;
    allowSubmit: boolean;
    submitButtonText: string;
}
