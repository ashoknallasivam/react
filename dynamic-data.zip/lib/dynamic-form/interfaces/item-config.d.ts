import { OptionsConfig } from './options-config';
export interface ItemConfig {
    label?: string;
    name?: string;
    value?: string;
    order?: number;
    options?: OptionsConfig;
}
