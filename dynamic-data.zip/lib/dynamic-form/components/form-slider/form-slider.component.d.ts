import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormSliderComponent extends DynamicBaseComponent {
}
