import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormPasswordComponent extends DynamicBaseComponent {
}
