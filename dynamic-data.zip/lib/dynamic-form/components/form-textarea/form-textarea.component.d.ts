import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormTextareaComponent extends DynamicBaseComponent {
}
