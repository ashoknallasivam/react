import { OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { DynamicFormBuilder } from '../../dynamic-form-builder';
import { DialogConfig } from '../../interfaces/dialog-config';
import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';
export declare class LayoutEditorComponent implements Field, OnInit {
    dialog: MatDialog;
    config: FieldConfig;
    group: FormGroup;
    fb: DynamicFormBuilder;
    array: FormArray;
    typeSelectOptions: DialogConfig;
    viewSourceOptions: DialogConfig;
    elementConfigOptions: DialogConfig;
    previewOptions: DialogConfig;
    constructor(dialog: MatDialog);
    ngOnInit(): void;
    add(): void;
    viewSource(): void;
    onElementChange(index: number, config: any): void;
    moveElement(index: number, direction: string): void;
    remove(index: any): void;
    preview(): void;
    getElementHeading(elementConfig: any): any;
    getElementLabel(elementConfig: any, group: any): any;
}
