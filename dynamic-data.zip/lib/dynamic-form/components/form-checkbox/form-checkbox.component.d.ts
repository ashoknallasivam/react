import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormCheckboxComponent extends DynamicBaseComponent {
    getConfig(): FieldConfig;
    specifyConfig(): FieldConfig;
    change(): void;
}
