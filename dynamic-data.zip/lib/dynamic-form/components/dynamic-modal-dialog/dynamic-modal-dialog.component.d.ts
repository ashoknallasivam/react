import { MatDialogRef } from '@angular/material';
import { DialogConfig } from '../../interfaces/dialog-config';
import { DynamicFormComponent } from '../dynamic-form/dynamic-form.component';
export declare class DynamicModalDialogComponent {
    dialogRef: MatDialogRef<DynamicModalDialogComponent>;
    data: DialogConfig;
    modalForm: DynamicFormComponent;
    primaryButtonText: string;
    secondaryButtonText: string;
    returnValue?: boolean;
    constructor(dialogRef: MatDialogRef<DynamicModalDialogComponent>, data: DialogConfig);
    checkValidity(): boolean;
    displayCancel(): boolean;
    cancel(): void;
}
