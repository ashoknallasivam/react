import { OnInit } from '@angular/core';
import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormRadioComponent extends DynamicBaseComponent implements OnInit {
    width: number;
    isList: boolean;
    ngOnInit(): void;
    specifyConfig(value: string): FieldConfig;
    change(): void;
}
