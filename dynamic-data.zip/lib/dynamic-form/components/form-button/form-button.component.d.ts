import { FormGroup } from '@angular/forms';
import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';
export declare class FormButtonComponent implements Field {
    config: FieldConfig;
    group: FormGroup;
    setValidators(): void;
}
