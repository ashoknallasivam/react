import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormSlideToggleComponent extends DynamicBaseComponent {
}
