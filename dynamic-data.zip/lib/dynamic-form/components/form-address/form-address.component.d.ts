import { OnInit } from '@angular/core';
import { MapsAPILoader } from '@agm/core';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormAddressComponent extends DynamicBaseComponent implements OnInit {
    private mapsAPILoader;
    constructor(mapsAPILoader: MapsAPILoader);
    ngOnInit(): void;
    geolocate(autocomplete: any): void;
}
