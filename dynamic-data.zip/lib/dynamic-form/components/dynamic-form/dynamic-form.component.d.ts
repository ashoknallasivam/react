import { ElementRef, EventEmitter, OnChanges, OnInit } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { DynamicFormBuilder } from '../../dynamic-form-builder';
import { FieldConfig } from '../../interfaces/field-config';
export declare class DynamicFormComponent implements OnChanges, OnInit {
    private elRef;
    layout?: FieldConfig[];
    entity?: any;
    valueChanges: EventEmitter<any>;
    cancel: EventEmitter<any>;
    remove: EventEmitter<any>;
    submit: EventEmitter<any>;
    id: string;
    form: FormGroup;
    dynFormBuilder: DynamicFormBuilder;
    submitted: boolean;
    readonly changes: import("rxjs/internal/Observable").Observable<any>;
    readonly valid: boolean;
    readonly errors: {};
    readonly value: any;
    constructor(elRef: ElementRef);
    ngOnInit(): void;
    ngOnChanges(): void;
    reconcileForm(): void;
    reconcileLayout(): void;
    validateFormControls(control: AbstractControl): void;
    validate(): void;
    handleSubmit(event: Event): void;
    setDisabled(name: string, disable: boolean): void;
    getValue(name: string): any;
    getControlErrors(key: string, control: any): {
        field: string;
        errors: any;
    };
    getErrors(group: FormGroup): {};
    getControlsForGroup(group: FormGroup): AbstractControl[];
}
