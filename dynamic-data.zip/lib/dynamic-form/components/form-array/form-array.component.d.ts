import { OnInit } from '@angular/core';
import { FormArray } from '@angular/forms';
import { DynamicFormBuilder } from '../../dynamic-form-builder';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormArrayComponent extends DynamicBaseComponent implements OnInit {
    fb: DynamicFormBuilder;
    array: FormArray;
    ngOnInit(): void;
    add(): void;
    remove(index: any): void;
}
