import { OnInit } from '@angular/core';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormStatesComponent extends DynamicBaseComponent implements OnInit {
    ngOnInit(): void;
}
