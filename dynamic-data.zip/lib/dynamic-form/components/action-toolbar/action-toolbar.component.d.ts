import { FormGroup } from '@angular/forms';
import { ActionButtons } from '../../enumerations/action-buttons';
import { Field } from '../../interfaces/field';
import { FieldConfig } from '../../interfaces/field-config';
export declare class ActionToolbarComponent implements Field {
    config: FieldConfig;
    group: FormGroup;
    getActionButtonEnum(button: string): ActionButtons;
    getButtonText(button: string): string;
}
