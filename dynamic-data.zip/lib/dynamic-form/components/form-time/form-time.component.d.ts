import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormTimeComponent extends DynamicBaseComponent {
    hint(): string;
    inputMask(): string;
    pattern(): string;
    patternValidationMessage(): string;
}
