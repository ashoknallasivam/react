import { OnInit } from '@angular/core';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormDateComponent extends DynamicBaseComponent implements OnInit {
    startAt?: Date;
    minDate?: Date;
    maxDate?: Date;
    minDateString?: string;
    maxDateString?: string;
    ngOnInit(): void;
    buildDate(attr: any): Date;
    formatDateString(date: Date): string;
    dateFilter(d: Date): boolean;
}
