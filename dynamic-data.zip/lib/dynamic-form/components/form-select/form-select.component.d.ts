import { FieldConfig } from '../../interfaces/field-config';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormSelectComponent extends DynamicBaseComponent {
    specifyConfig(value: string): FieldConfig;
    change(): void;
}
