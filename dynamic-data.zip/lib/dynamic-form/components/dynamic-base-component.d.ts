import { OnInit } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { Field } from '../interfaces/field';
import { FieldConfig } from '../interfaces/field-config';
export declare class DynamicBaseComponent implements Field, OnInit {
    id: string;
    config: FieldConfig;
    group: FormGroup;
    constructor();
    ngOnInit(): void;
    resetControls(config: any, disable?: boolean, nestedGroup?: FormGroup): void;
    findControl(group: AbstractControl, properties: string[]): any;
    handleSpecifyConfig(group: FormGroup, spec: any, disable: boolean): void;
    handleEnableDisable(validation: any, onInit?: boolean): void;
    requiredIfChanges(): void;
    requiredIf(): any;
    showIfChanges(): void;
    showIf(): any;
}
