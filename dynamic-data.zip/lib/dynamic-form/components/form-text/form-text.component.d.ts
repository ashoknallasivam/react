import { OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ItemConfig } from '../../interfaces/item-config';
import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormTextComponent extends DynamicBaseComponent implements OnInit {
    filteredItems: Observable<any[]>;
    items: string[];
    ngOnInit(): void;
    getItems(config: ItemConfig[]): string[];
    filterItems(text: string): string[];
}
