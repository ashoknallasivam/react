import { DynamicBaseComponent } from '../dynamic-base-component';
export declare class FormTextMaskComponent extends DynamicBaseComponent {
    hint(): string;
    inputMask(): string;
    pattern(): string;
    patternValidationMessage(): string;
    dropSpecialCharacters(): boolean;
}
