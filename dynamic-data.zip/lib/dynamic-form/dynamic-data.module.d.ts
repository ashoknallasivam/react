export declare class DynamicDataModule {
}
