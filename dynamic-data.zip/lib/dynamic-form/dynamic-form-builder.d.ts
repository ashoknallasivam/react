import { AbstractControl, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { FieldConfig } from './interfaces/field-config';
import { ItemConfig } from './interfaces/item-config';
export declare class DynamicFormBuilder {
    fb: FormBuilder;
    constructor();
    createForm(): FormGroup;
    reconcileForm(form: FormGroup, layout: FieldConfig[], entity: any): void;
    reconcileGroup(group: FormGroup, configs: FieldConfig[], entity: any): void;
    createControl(config: FieldConfig, entity?: any): AbstractControl;
    createGroup(groupConfig: any, entity?: any): FormGroup;
    createArray(arrayConfig: FieldConfig, length: number, entity?: any): FormArray;
    createEditorArray(arrayConfig: FieldConfig, entity?: any): FormArray;
    createGroupValidator(config?: any): {
        validator: () => any;
    };
    createArrayValidator(config?: any): import("@angular/forms/src/directives/validators").ValidatorFn;
    isGroup(type: string): boolean;
    isArray(type: string): boolean;
    isEditorArray(type: string): boolean;
    isControl(type: string): boolean;
    hasSpecify(config: FieldConfig | ItemConfig): boolean;
    getSpecify(items: ItemConfig[]): FieldConfig[];
}
