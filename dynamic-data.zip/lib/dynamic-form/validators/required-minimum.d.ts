export declare class RequiredMinimumValidator {
    validate: () => any;
    constructor(min: number);
    validateRequiredMin(min: number): any;
}
