import { FormControl, Validator } from '@angular/forms';
export declare class MaximumNumberValidatorDirective implements Validator {
    maxNumber: string;
    validate(control: FormControl): {
        [key: string]: any;
    };
}
