import { FormControl, Validator } from '@angular/forms';
export declare class MinimumNumberValidatorDirective implements Validator {
    minNumber: string;
    validate(control: FormControl): {
        [key: string]: any;
    };
}
