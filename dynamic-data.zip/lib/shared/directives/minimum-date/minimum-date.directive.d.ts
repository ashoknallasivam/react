import { FormControl, Validator } from '@angular/forms';
export declare class MinimumDateValidatorDirective implements Validator {
    minDate: string;
    validate(control: FormControl): {
        [key: string]: any;
    };
}
