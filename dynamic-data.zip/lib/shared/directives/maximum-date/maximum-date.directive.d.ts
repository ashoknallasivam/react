import { FormControl, Validator } from '@angular/forms';
export declare class MaximumDateValidatorDirective implements Validator {
    maxDate: string;
    validate(control: FormControl): {
        [key: string]: any;
    };
}
