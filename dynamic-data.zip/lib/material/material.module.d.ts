import 'hammerjs';
export declare class MaterialModule {
    constructor(parentModule: MaterialModule);
}
